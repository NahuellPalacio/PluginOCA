define([
    "jquery",
    "uiComponent",
    "ko",
    "Magento_Checkout/js/model/quote",
], function ($, Component, ko, quote) {
    "use strict";

    var ocaShippingMethod = window.checkoutConfig.ocaShippingMethod;
    var isToMyDoor = window.checkoutConfig.isToMyDoor;
    var isToBranch = window.checkoutConfig.isToBranch;
    var getBranchUrl = window.checkoutConfig.getBranchUrl;
    var checkedDefault = window.checkoutConfig.checkedDefault;
    var selectedBranchArray = window.checkoutConfig.selectedBranchArray;
    var selectedValueBranchList = window.checkoutConfig.selectedValueBranchList;
    var branchList = window.checkoutConfig.branchList;
    var shipToSpecificCountries = window.checkoutConfig.shipToSpecificCountries;
    var defaultCountry = window.checkoutConfig.defaultCountry;
    var branchInfoKeys = window.checkoutConfig.branchInfoKeys;
    var ocaAllOp = window.checkoutConfig.allOp;

    function getOperativeDetails(shippingMethod, ocaAllOp) {
        var methodCode = shippingMethod ? shippingMethod.method_code : null;
        for (var key in ocaAllOp) {
            if (ocaAllOp.hasOwnProperty(key)) {
                var operativa = ocaAllOp[key];
                if (methodCode && methodCode.endsWith("_" + operativa.code)) {
                    return operativa;
                }
            }
        }
        return null;
    }

    return Component.extend({
        visible: ko.observable(!quote.isVirtual()),
        defaults: {
            template: "Oca_TrackEPak/additional-oca-shipping",
        },
        selectedToBranch: ko.observable(checkedDefault == "to_branch"),
        showWarningMessage: ko.observable(!selectedBranchArray),
        warningMessage: ko.observable("Por favor seleccionar una Sucursal OCA"),
        isToMyDoor: isToMyDoor,
        isToBranch: isToBranch,
        checkedDefault: checkedDefault,
        selectedValueBranchList: ko.observable(selectedValueBranchList),
        branchList: ko.observableArray(branchList),

        initialize: function () {
            this._super();
            this.initObservable();
        },

        initObservable: function () {
            var self = this;
            this._super();
            this.selectedMethod = ko.computed(function () {
                var method = quote.shippingMethod()
                    ? quote.shippingMethod()["carrier_code"] +
                      "_" +
                      quote.shippingMethod()["method_code"]
                    : null;
                var operativaDetails = getOperativeDetails(
                    quote.shippingMethod(),
                    ocaAllOp
                );
                var isOcaShipping = method == ocaShippingMethod;

                self.handleShippingAddressForm(isOcaShipping, operativaDetails);
                self.selectedToBranch(
                    operativaDetails ? operativaDetails.type === "4" : false
                );

                self.showHideShippingAddressForm(!self.selectedToBranch());

                console.log("selectedMethod", self.selectedToBranch());
                return isOcaShipping;
            });

            return this;
        },

        myAfterRender: function () {
            console.log("function myAfterRender");
            this.afterLoad();
        },

        afterLoad: function () {
            console.log("function afterLoad");
            this.setSelectedBranch(selectedBranchArray);
        },

        showHideShippingAddressForm: function (show) {
            if (show) {
                $("#co-shipping-form").show();
            } else {
                $("#co-shipping-form").hide();
            }
        },

        handleShippingAddressForm: function (isOcaShipping, operativaDetails) {
            console.log("function handleShippingAddressForm");
            this.setupAddressCountry(isOcaShipping);
            this.showHideShippingAddressForm(this.selectedToBranch);
        },

        setupAddressCountry: function (isOcaShipping) {
            if (shipToSpecificCountries === false) {
                return;
            }

            if (isOcaShipping) {
                $("#shipping-new-address-form select[name='country_id'] option")
                    .attr("disabled", true)
                    .addClass("no-display");
                $(
                    '#shipping-new-address-form select[name="country_id"] option[value=""]'
                )
                    .attr("disabled", false)
                    .removeClass("no-display");
                $.each(shipToSpecificCountries, function (index, value) {
                    $(
                        '#shipping-new-address-form select[name="country_id"] option[value="' +
                            value +
                            '"]'
                    )
                        .attr("disabled", false)
                        .removeClass("no-display");
                });

                var selectedCountry = $(
                    "#shipping-new-address-form select[name='country_id']"
                ).val();
                if (
                    !selectedCountry ||
                    $.inArray(selectedCountry, shipToSpecificCountries) === -1
                ) {
                    $("#shipping-new-address-form select[name='country_id']")
                        .val(defaultCountry)
                        .trigger("change");
                }
            } else {
                $("#shipping-new-address-form select[name='country_id'] option")
                    .attr("disabled", false)
                    .removeClass("no-display");
            }
        },

        handleSearchBranch: function (showSearch) {
            if (showSearch) {
                $("#search_branch").show();
            } else {
                $("#search_branch").hide();
            }
        },

        searchBranches: function () {
            var ocazipcode = $("#oca_zipcode").val();
            var oldZipcode = $("#oca_zipcode").attr("zipcode");
            if (oldZipcode != ocazipcode && ocazipcode.length >= 4) {
                $.ajax({
                    showLoader: true,
                    url: getBranchUrl + "postalcode/" + ocazipcode,
                    type: "get",
                    dataType: "json",
                    success: function (data) {
                        var html =
                            "<option>" +
                            $.mage.__("Choose a Branch...") +
                            "</option>";
                        var i = 0;
                        var hasSelected = false;
                        if (data) {
                            for (i; i < data.length; i++) {
                                var selected = "";
                                if (selectedValueBranchList) {
                                    var mybranch = JSON.parse(
                                        selectedValueBranchList
                                    );
                                    console.log(
                                        mybranch["Sucursal"],
                                        data[i]["Sucursal"]
                                    );
                                    if (
                                        mybranch["Sucursal"] ==
                                            data[i]["Sucursal"] &&
                                        mybranch["CodigoPostal"] ==
                                            data[i]["CodigoPostal"]
                                    ) {
                                        console.log("===");
                                        selected = 'selected="selected"';
                                        hasSelected = true;
                                    }
                                }

                                html =
                                    html +
                                    "<option " +
                                    selected +
                                    " value='" +
                                    JSON.stringify(data[i]) +
                                    "'>" +
                                    data[i]["Sucursal"] +
                                    " (" +
                                    data[i]["CodigoPostal"] +
                                    ")</option>";
                            }
                        }
                        $("#branch_list").html(html);
                        $("#oca_zipcode").attr("zipcode", ocazipcode);
                        if (!hasSelected) {
                            $("#previewSelectedBranch").html("");
                            $("#validate-branch-message").show();
                        } else {
                            $("#validate-branch-message").hide();
                        }
                    },
                });
            }
        },

        operatoryMethodChange: function (data, event) {
            console.log("function operatoryMethodChange");
            var showSearch = $("#input_to_branch:checked").length > 0;
            this.handleSearchBranch(showSearch);
            this.setSelectedBranch(selectedBranchArray);
        },

        setSelectedBranch: function (branchData) {
            console.log("setSelectedBranch", branchData);
            if (branchData) {
                this.branchChange();

                var html = "";
                $.each(branchData, function (index, value) {
                    if (branchInfoKeys[index] !== undefined) {
                        html =
                            html +
                            "<div><strong>" +
                            branchInfoKeys[index] +
                            "</strong>: " +
                            value +
                            "</div>";
                    }
                });

                $("#validate-branch-message").hide();
                $("#previewSelectedBranch").html(html);
            } else {
                $("#validate-branch-message").show();
            }
        },

        branchChange: function () {
            var branchData = $("#branch_list").val();
            console.log("branchChange", branchData);
            $("#previewSelectedBranch").html("");
            if (branchData) {
                branchData = JSON.parse(branchData);
                $("#shipping-new-address-form input[name='firstname']").val(
                    branchData["Sucursal"]
                );
                $("#shipping-new-address-form input[name='firstname']").trigger(
                    "change"
                );

                $("#shipping-new-address-form input[name='lastname']").val(
                    branchData["Sigla"]
                );
                $("#shipping-new-address-form input[name='lastname']").trigger(
                    "change"
                );

                $("#shipping-new-address-form input[name='street[0]']").val(
                    branchData["Numero"] + " " + branchData["Calle"]
                );
                $("#shipping-new-address-form input[name='street[0]']").trigger(
                    "change"
                );

                $("#shipping-new-address-form input[name='city']").val(
                    branchData["Provincia"]
                );
                $("#shipping-new-address-form input[name='city']").trigger(
                    "change"
                );

                $("#shipping-new-address-form select[name='country_id']").val(
                    defaultCountry
                );
                $(
                    "#shipping-new-address-form select[name='country_id']"
                ).trigger("change");

                $.each(
                    $(
                        "#shipping-new-address-form select[name='region_id'] > option"
                    ),
                    function () {
                        if ($(this).val()) {
                            $(
                                "#shipping-new-address-form select[name='region_id']"
                            ).val($(this).val());
                            return false;
                        }
                    }
                );

                $("#shipping-new-address-form input[name='telephone']").val(
                    branchData["Telefono"]
                );
                $("#shipping-new-address-form input[name='telephone']").trigger(
                    "change"
                );

                $("#shipping-new-address-form input[name='postcode']").val(
                    branchData["CodigoPostal"]
                );
                $("#shipping-new-address-form input[name='postcode']").trigger(
                    "change"
                );

                var html = "";
                $.each(branchData, function (index, value) {
                    if (branchInfoKeys[index] !== undefined) {
                        html =
                            html +
                            "<div><strong>" +
                            branchInfoKeys[index] +
                            "</strong>: " +
                            value +
                            "</div>";
                    }
                });
                $("#validate-branch-message").hide();
                $("#previewSelectedBranch").html(html);
            } else {
                $("#validate-branch-message").show();
            }
        },
    });
});
