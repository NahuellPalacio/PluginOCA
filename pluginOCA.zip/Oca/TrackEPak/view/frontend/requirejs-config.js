var config = {
    "map": {
        "*": {
            "Magento_Checkout/js/model/shipping-save-processor/default": "Oca_TrackEPak/js/model/shipping-save-processor/default",
            'Magento_Checkout/js/view/shipping-information': 'Oca_TrackEPak/js/view/shipping-information',
        }
    }
};