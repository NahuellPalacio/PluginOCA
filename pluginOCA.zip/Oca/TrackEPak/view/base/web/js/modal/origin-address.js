define([
  'ko',
  'underscore',
  'jquery',
  'Magento_Ui/js/modal/modal-component',
  'Oca_TrackEPak/js/model/branch-service',
  'Oca_TrackEPak/js/model/operative-service',
  'Oca_TrackEPak/js/model/shipping-service',
], function (ko, _, $, modal, branchService, operativeService, shippingService) {
  'use strict';

  var GROUP_FROM_DOOR = ['1', '3'];
  var GROUP_TO_DOOR = ['1', '2'];

  function parseOperatories(operatories) {
    return _.map(operatories, function (op) {
      return { value: op.code, label: op.code + " " + op.name };
    })
  }

  function filterOperatoriesByDestinyOfCurrent(operatories, currentOperatoryId) {
    var currentOperatory = operatories.find(function (op) { return op.code == currentOperatoryId; });
    if (currentOperatory) {
      var destinyFilter = function (op) {
        return isDestinyDoor(currentOperatory.type) ? isDestinyDoor(op.type) : !isDestinyDoor(op.type);
      }
      return _.filter(operatories, function (op) {
        return destinyFilter(op);
      })
    }
  }

  function parseBranches(branches) {
    return _.map(branches, function (branch) {
      return { value: branch.IdCentroImposicion, label: branch.Calle + ' ' + branch.Numero + ' - ' + branch.Localidad + ', ' + branch.Provincia };
    })
  }

  function isOriginDoor(operatoryType) {
    return _.contains(GROUP_FROM_DOOR, operatoryType);
  }

  function isDestinyDoor(operatoryType) {
    return _.contains(GROUP_TO_DOOR, operatoryType);
  }

  return modal.extend({

    operatories: ko.observableArray([]),
    operatorySelected: null,
    shippingToChange: null,

    resetFields: function () {
      var branchFieldsetElement = this.getChild('general').getChild('branch_origin_group');
      var doorFieldsetElement = this.getChild('general').getChild('door_origin_group');

      branchFieldsetElement.visible(false);
      branchFieldsetElement.getChild('postal_code').clear();
      branchFieldsetElement.getChild('select_branches').disable();
      branchFieldsetElement.getChild('select_branches').clear();

      doorFieldsetElement.visible(false);
      doorFieldsetElement.getChild('select_province').clear();
      doorFieldsetElement.getChild('city').clear();
      doorFieldsetElement.getChild('street_and_number').clear();
      doorFieldsetElement.getChild('postal_code').clear();
    },

    onChangeOperatory: function (operatoryCode) {
      this.resetFields();
      this.operatorySelected = this.operatories().find(function (operatory) { return operatory.code === operatoryCode });
      if (this.operatorySelected) {
        if (isOriginDoor(this.operatorySelected.type)) {
          this.getChild('general').getChild('door_origin_group').visible(true);
        } else {
          this.getChild('general').getChild('branch_origin_group').visible(true);
        }
      }
    },

    onChangePostalCode: function (postalCode) {
      var branchSelectElement = this.getChild('general').getChild('branch_origin_group').getChild('select_branches');
      if (postalCode.length === 4) {
        $('body').trigger('processStart');
        branchService.findByPostalCode(postalCode)
          .done(
            function(response) {
              branchSelectElement.enable();
              branchSelectElement.setOptions(parseBranches(response));
            }
          ).always(
            function () {
              $('body').trigger('processStop');
            }
          );
      }
    },

    changeShippingOrigin: function (data) {
      this.shippingToChange = data.entity_id;
      if (data) {
        this.initOperatoriesSelect(data.operatory_id);
        this.setTitle('Cambiar origen de la orden: ' + data.increment_id);
        this.openModal();
      }

    },

    initOperatoriesSelect: function (currentOperatoryId) {
      var self = this;
      $('body').trigger('processStart');
      var operatoriesSelectElement = this.getChild('general').getChild('select_operatories');
      operatoriesSelectElement.reset();
      operativeService.findAll()
        .done(
          function (response) {
            var operatoriesOptions = parseOperatories(filterOperatoriesByDestinyOfCurrent(response, currentOperatoryId));
            operatoriesSelectElement.enable();
            operatoriesSelectElement.setOptions(operatoriesOptions);
            self.operatories(response);
          }
        ).always(
          function () {
            $('body').trigger('processStop');
          }
        );
    },

    saveOrigin: function () {
      var payload = {
        entity_id: this.shippingToChange,
        operatory_id: this.operatorySelected.code,
        operatory_description: this.operatorySelected.name,
      }
      if (isOriginDoor(this.operatorySelected.type)) {
        var groupOriginDoor = this.getChild('general').getChild('door_origin_group');
        payload.warehouse_city = groupOriginDoor.getChild('city').value();
        payload.warehouse_region = groupOriginDoor.getChild('select_province').value();
        payload.warehouse_street_and_number = groupOriginDoor.getChild('street_and_number').value();
        payload.warehouse_postal_code = groupOriginDoor.getChild('postal_code').value();
        payload.shipping_address_id = 0;
      } else {
        payload.shipping_address_id = this.getChild('general').getChild('branch_origin_group').getChild('select_branches').value();
        payload.shipping_origin_branch_postcode = this.getChild('general').getChild('branch_origin_group').getChild('postal_code').value();
        payload.branch_address = this.getChild('general').getChild('branch_origin_group').getChild('select_branches').getOption(payload.shipping_address_id).label;
      }

      $('body').trigger('processStart');
      shippingService.updateOrigin(payload)
        .done(
          function () {
            window.location.href = window.location.href;
          }
        );
    }
  });
});
