define([
  'underscore',
  'jquery',
  'Magento_Ui/js/modal/modal-component',
  'Oca_TrackEPak/js/model/shipping-service',
], function (_, $, modal, shippingService) {
  'use strict';

  return modal.extend({

    shippingToChange: null,

    changePackages: function (data) {
      this.shippingToChange = data.entity_id;
      if (data) {
        this.setTitle('Cantidad de bultos a enviar de la orden: ' + data.increment_id);
        this.getChild('general').getChild('packages_number').value(data.packages_number);
        this.openModal();
      }
    },

    saveNumberOfPackages: function () {
      $('body').trigger('processStart');
      var payload = {
        entity_id: this.shippingToChange,
        packages_number: this.getChild('general').getChild('packages_number').value()
      };
      this.closeModal();
      shippingService.updatePackagesNumber(payload)
        .always(
          function () {
            window.location.href = window.location.href;
          }
        );
    }

  });
});
