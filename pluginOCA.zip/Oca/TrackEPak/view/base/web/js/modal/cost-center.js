define([
  'ko',
  'underscore',
  'jquery',
  'Magento_Ui/js/modal/modal-component',
  'Oca_TrackEPak/js/model/cost-centers-service',
  'Oca_TrackEPak/js/model/shipping-service',
], function (ko, _, $, modal, costCenterService, shippingService) {
  'use strict';

  function parseCostCenters(costCenters) {
      var options = _.map(costCenters, function (costCenter) {
        var labelSelect = costCenter.costCenterId + ' - ' + costCenter.street + ' ' + costCenter.number + ', ' + costCenter.city + ' (' + costCenter.postalCode.trim() + ')';
        return { value: costCenter.costCenterId, label: labelSelect };
      });
      return options;
  }

  return modal.extend({

    costCenters: ko.observableArray([]),
    costCenterSelected: null,
    operativeSellerIdToChange: null,
    operativeType: null,
    shippingIdToChange: null,

    changeCostCenter: function (data) {
      this.operativeSellerIdToChange = data.seller_operative_entity_id;
      this.operativeType = data.type;
      this.shippingIdToChange = data.shipping_entity_id;
      if (data) {
        this.initCostCenterSelect(data.code);
        this.setTitle('Cambiar centro de costo de la operativa: ' + data.code);
        this.openModal();
      }
    },

    initCostCenterSelect: function (currentOperatoryId) {
      var self = this;
      $('body').trigger('processStart');
      var costCentersSelectElement = this.getChild('general').getChild('select_cost_center');
      costCenterService.findByOperativeCode(currentOperatoryId)
        .done(
          function (response) {
            costCentersSelectElement.enable();
            costCentersSelectElement.setOptions(parseCostCenters(response));
            self.costCenters(response);
          }
        ).always(
          function () {
            $('body').trigger('processStop');
          }
        );
    },

    onChangeCostCenter: function (costCenterId) {
      this.costCenterSelected = this.costCenters().find(function (costCenter) { return costCenter.costCenterId === costCenterId });
    },

    updateCostCenterInShipping: function () {
      $('body').trigger('processStart');
      var costCenter = this.costCenterSelected;
      var consCenterDescription = costCenter.costCenterId + ' - ' + costCenter.street + ' ' + costCenter.number + ', ' + costCenter.city + ' (' + costCenter.postalCode.trim() + ')';
      var payload = {
        entity_id: this.shippingIdToChange,
        cost_center_id: this.costCenterSelected.costCenterId,
        cost_center_description: consCenterDescription,
      }
      this.closeModal();
      shippingService.updateCostCenter(payload)
        .always(
          function () {
            window.location.href = window.location.href;
          }
        );
    },
  });
});
