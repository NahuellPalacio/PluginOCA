define(
  [
    'jquery',
  ],
  function ($) {
    'use strict';

    return {
      updateOrigin: function (payload) {
        var currentUrl = window.location.href;
        currentUrl = currentUrl.substring(0, currentUrl.indexOf("admin"));
        var serviceUrl = currentUrl + 'ocatrackepak/ajax_shippings/updateorigin';
        return $.post(serviceUrl, payload);
      },
      updatePackagesNumber: function (payload) {
        var currentUrl = window.location.href;
        currentUrl = currentUrl.substring(0, currentUrl.indexOf("admin"));
        var serviceUrl = currentUrl + 'ocatrackepak/ajax_shippings/updatepackages';
        return $.post(serviceUrl, payload);
      },        
      updateCostCenter: function (payload) {
        var currentUrl = window.location.href;
        currentUrl = currentUrl.substring(0, currentUrl.indexOf("admin"));
        var serviceUrl = currentUrl + 'ocatrackepak/ajax_shippings/updatecostcenter';
        return $.post(serviceUrl, payload);
      }
    }
  });
