define(
    [
        'mage/storage',
        'jquery',
    ],
    function (storage, $) {
        'use strict';

        return {
            findByPostalCode: function (postalCodeToSearch) {
                var currentUrl = window.location.href;
                currentUrl = currentUrl.substring(0, currentUrl.indexOf("admin"));
                var serviceUrl = currentUrl + 'ocatrackepak/ajax_branches/findbypostalcode/postalcode/' + postalCodeToSearch;
                return storage.get(serviceUrl);
            },
            findDefault: function () {
                var currentUrl = window.location.href;
                currentUrl = currentUrl.substring(0, currentUrl.indexOf("admin"));
                var serviceUrl = currentUrl + 'ocatrackepak/ajax_branches/finddefault';
                return storage.get(serviceUrl);
            },
            saveDefault: function (payload) {
                var currentUrl = window.location.href;
                currentUrl = currentUrl.substring(0, currentUrl.indexOf("admin"));
                var serviceUrl = currentUrl + 'ocatrackepak/ajax_branches/savedefault' 
                return $.post(serviceUrl, payload);
            }
        }
    }
);
