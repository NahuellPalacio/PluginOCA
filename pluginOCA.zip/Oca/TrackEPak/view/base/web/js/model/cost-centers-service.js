define(
  [
    'mage/storage',
    'jquery',
  ],
  function (storage, $) {
    'use strict';

    return {
      findByOperativeCode: function (operativeCode) {
        var currentUrl = window.location.href;
        currentUrl = currentUrl.substring(0, currentUrl.indexOf("admin"));
        var serviceUrl = currentUrl + 'ocatrackepak/ajax_costcenters/findbyoperativecode/operative/' + operativeCode;
        return storage.get(serviceUrl);
      },
    }
});
