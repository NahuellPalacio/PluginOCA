/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * @api
 */
define(
  [
    'mage/storage',
  ],
  function (storage) {
    'use strict';

    return {
      findById: function (id) {
        var currentUrl = window.location.href;
        currentUrl = currentUrl.substring(0, currentUrl.indexOf("admin"));
        var serviceUrl = currentUrl + 'ocatrackepak/ajax_operatives/findbyid/id/' + id;
        return storage.get(serviceUrl);
      },
      findAll: function () {
        var currentUrl = window.location.href;
        currentUrl = currentUrl.substring(0, currentUrl.indexOf("admin"));
        var serviceUrl = currentUrl + 'ocatrackepak/ajax_operatives/findall';
        return storage.get(serviceUrl);
      }
    }
  }
);
