define([
  'underscore',
  'jquery',
  'Magento_Ui/js/form/form',
  'uiRegistry',
  'Oca_TrackEPak/js/model/branch-service'
], function(_, $, form, registry, branchService){
  'use strict';

  function updateSelect(data) {
    var options = _.map(data, function (branch) {
      var labelSelect = branch.IdCentroImposicion + ' - ' + branch.Calle + ' ' + branch.Numero + ', ' + branch.Localidad + ' (' + branch.CodigoPostal + ')';
      return { value: branch.IdCentroImposicion, label: labelSelect };
    });
    if (options) {
      var defaultBranchSelectElement = registry.get('index = default_branch_id');
      defaultBranchSelectElement.enable();
      defaultBranchSelectElement.setOptions(options);
    } else {
      defaultBranchSelectElement.disable();
      defaultBranchSelectElement.setOptions([]);
    }
  }

  return form.extend({

    onChangeType: function(type) {
      var fieldsetDefaultBranch = registry.get('index = default_branch_group');
      if (type === '2' || type === '4') {        
        fieldsetDefaultBranch.visible(true);
      } else {
        fieldsetDefaultBranch.visible(false);
      }
    },

    onChangePostalCode: function(postalCode) {
      if (postalCode.length >= 4) {
        $("body").trigger('processStart');
        var self = this;
        var boundUpdateSelect = updateSelect.bind(this);
        branchService.findByPostalCode(postalCode)
          .done(function(data) {
            boundUpdateSelect(data);
          })
          .fail(function(e) {
            console.error(e);
          })
          .always(function() {
            $("body").trigger('processStop');
          });
      } else {
        var defaultBranchSelectElement = registry.get('index = default_branch_id');
        defaultBranchSelectElement.disable();
        defaultBranchSelectElement.setOptions([]);
      }
    },

    onChangeDefaultBranch: function(defaultBranchId) {      
      var defaultBranchSelectElement = registry.get('index = default_branch_id');
      var branchSelected = _.find(defaultBranchSelectElement.options(), function (branch) {
        return branch.value === defaultBranchId;
      });
      var defaultBranchDescriptionElement = registry.get('index = default_branch_description');
      if (branchSelected) {
        defaultBranchDescriptionElement.value(branchSelected.label);
      } else {
        defaultBranchDescriptionElement.value("");
      }
    }

  });
});