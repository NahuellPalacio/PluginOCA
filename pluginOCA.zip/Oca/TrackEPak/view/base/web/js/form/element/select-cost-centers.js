define([
  'underscore',
  'jquery',
  'Magento_Ui/js/form/element/select',
  'Oca_TrackEPak/js/model/cost-centers-service',
  'Oca_TrackEPak/js/model/operative-service',
  'uiRegistry'
], function (_, $, select, costCentersService, operativeService, registry) {
  'use strict';

  function updateSelect(data) {
    var options = _.map(data, function (costCenter) {
      var labelSelect = costCenter.costCenterId + ' - ' + costCenter.street + ' ' + costCenter.number + ', ' + costCenter.city + ' (' + costCenter.postalCode.trim() + ')';
      return { value: costCenter.costCenterId, label: labelSelect };
    });
    if (options) {
      this.enable();
      this.setOptions(options);
    } else {
      this.disable();
      this.setOptions([]);
    }
  }

  return select.extend({
    
    initialize: function () {
      this._super();
      var operativeCodeElement = registry.get('index = code')
      this.getCostCenters(operativeCodeElement.value());
      return this;
    },

    getCostCenters: function (operativeCode) {
      if (operativeCode.length >= 5) {
        var self = this;
        $("body").trigger('processStart');
        var boundUpdateSelect = updateSelect.bind(this);
        costCentersService.findByOperativeCode(operativeCode)
          .done(function(data) {
            boundUpdateSelect(data);
            var operativeIdElement = registry.get('index = entity_id');
            if (operativeIdElement.value()) {
              operativeService.findById(operativeIdElement.value())
                .done(function(data) {
                    if (data.cost_center_id) {
                      self.value(data.cost_center_id);
                    }
                })
                .fail(function(e) {console.log(e)});
            }
          })
          .fail(function(e) {
            console.error(e);
          })
          .always(function() {
            $("body").trigger('processStop');
          });
      } else {
        this.disable();
        this.setOptions([]);
      }
    }
  });
}); 