define([
  'underscore',
  'jquery',
  'Magento_Ui/js/form/element/select',
  'Oca_TrackEPak/js/model/branch-service',
  'Oca_TrackEPak/js/model/operative-service',
  'uiRegistry'
], function (_, $, select, branchService, operativeService, registry) {
  'use strict';

  function updateSelect(data) {
    var options = _.map(data, function (branch) {
      var labelSelect = branch.IdCentroImposicion + ' - ' + branch.Calle + ' ' + branch.Numero + ', ' + branch.Localidad + ' (' + branch.CodigoPostal + ')';
      return { value: branch.IdCentroImposicion, label: labelSelect };
    });
    if (options) {
      this.enable();
      this.setOptions(options);
    } else {
      this.disable();
      this.setOptions([]);
    }
  }

  function checkIfShowBranchDefaultFieldset() {
    var typeElement = registry.get('index = type');
    if (['2', '4'].includes(typeElement.value())) { // 2 y 4 son los valores que representan origen en sucursal
      registry.get('index = default_branch_group').visible(true);
    }
  }

  return select.extend({
    
    initialize: function () {
      this._super();
      var postalCodeElement = registry.get('index = default_branch_postal_code')
      checkIfShowBranchDefaultFieldset();
      this.getBranches(postalCodeElement.value());
      return this;
    },

    getBranches: function (postalCode) {
      if (postalCode.length >= 4) {
        $("body").trigger('processStart');
        var self = this;
        var boundUpdateSelect = updateSelect.bind(this);
        branchService.findByPostalCode(postalCode)
          .done(function(data) {
            boundUpdateSelect(data);
            var operativeIdElement = registry.get('index = entity_id');
            if (operativeIdElement.value()) {
              operativeService.findById(operativeIdElement.value())
                .done(function(data) {
                    if (data.default_branch_id) {
                      self.value(data.default_branch_id);
                    }
                })
                .fail(function(e) {console.log(e)});
            }
          })
          .fail(function(e) {
            console.error(e);
          })
          .always(function() {
            $("body").trigger('processStop');
          });
      } else {
        this.disable();
        this.setOptions([]);
      }
    }
  });
}); 