<?php

namespace Oca\TrackEPak\Controller\Ajax\CostCenters;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Oca\TrackEPak\Model\Ws\Ms\Adapter;
use Magento\Framework\App\Action\Action;

class findByOperativeCode extends Action implements HttpGetActionInterface
{
    /**
     * @var JsonFactory
     */
    protected $resultJsonFactory;

    /**
     * @var Adapter
     */
    protected $adapter;

    public function __construct(
        JsonFactory  $resultJsonFactory,
        Context $context
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $result = $this->resultJsonFactory->create();

        $this->adapter = $this->_objectManager->create(Adapter::class);
        $operativeCode = $this->_request->getParam('operative');
        $costCenters = $this->adapter->execGetCentroCostoPorOperativa($operativeCode);

        return $result->setData($costCenters);
    }
}
