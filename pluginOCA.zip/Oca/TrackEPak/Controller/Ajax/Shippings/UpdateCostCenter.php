<?php

namespace Oca\TrackEPak\Controller\Ajax\Shippings;

use Magento\Framework\App\Action\Context;
use Oca\TrackEPak\Logger\Logger;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\Action\Action;
use Oca\TrackEPak\Api\EpakShippingRepositoryInterface;
use Oca\TrackEPak\Model\EpakShippingFactory;
use Magento\Framework\Controller\Result\JsonFactory;


class UpdateCostCenter extends Action implements HttpPostActionInterface
{
  protected $logger;
  protected $epakShippingRepository;
  protected $epakShippingFactory;
  protected $resultJsonFactory;

  public function __construct(
    Logger $logger,
    EpakShippingFactory $epakShippingFactory,
    Context $context,
    EpakShippingRepositoryInterface $epakShippingRepository,
    JsonFactory $resultJsonFactory
  ) {
    $this->logger = $logger;
    $this->epakShippingFactory = $epakShippingFactory;
    $this->epakShippingRepository = $epakShippingRepository;
    $this->resultJsonFactory = $resultJsonFactory;
    parent::__construct($context);
  }

  public function execute()
  {
    $result  = $this->resultJsonFactory->create();
    $bodyData = $this->getRequest()->getPostValue();

    $this->logger->debug('Actualizando centro de costo envío Epak: ' . $bodyData['entity_id']);

    $epakShipping = $this->epakShippingFactory->create();
    $epakShippingToUpdate = $epakShipping->load($bodyData['entity_id']);
    $epakShippingToUpdate->setCostCenterId($bodyData['cost_center_id']);
    $epakShippingToUpdate->setCostCenterDescription($bodyData['cost_center_description']);
    $this->epakShippingRepository->save($epakShippingToUpdate);      
    
    return $result->setData($epakShippingToUpdate);
  }

}
