<?php

namespace Oca\TrackEPak\Controller\Ajax\Shippings;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Oca\TrackEPak\Logger\Logger;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\Action\Action;
use Oca\TrackEPak\Api\EpakShippingRepositoryInterface;
use Oca\TrackEPak\Model\OperatoryFactory;
use Oca\TrackEPak\Model\EpakShippingFactory;
use Magento\Framework\Controller\Result\JsonFactory;

class UpdateOrigin extends Action implements HttpPostActionInterface
{
  protected $logger;
  protected $epakShippingRepository;
  protected $epakShippingFactory;
  protected $operatoryFactory;
  protected $resultJsonFactory;

  public function __construct(
    Logger $logger,
    EpakShippingFactory $epakShippingFactory,
    Context $context,
    EpakShippingRepositoryInterface $epakShippingRepository,
    OperatoryFactory $operatoryFactory,
    JsonFactory $resultJsonFactory
  ) {
    $this->logger = $logger;
    $this->epakShippingFactory = $epakShippingFactory;
    $this->epakShippingRepository = $epakShippingRepository;
    $this->operatoryFactory = $operatoryFactory;
    $this->resultJsonFactory = $resultJsonFactory;
    parent::__construct($context);
  }

  /**
   * @return ResponseInterface|ResultInterface|void
   */
  public function execute()
  {
    $result  = $this->resultJsonFactory->create();
    $bodyData = $this->getRequest()->getPostValue();
    $this->logger->debug('Actializando envío: ' . $bodyData['entity_id']);
    $updatedShipping = $this->updateEpakShipping($bodyData);
    return $result->setData($updatedShipping);
  }

  private function updateEpakShipping($bodyData)
  {
    $operative = $this->operatoryFactory->create()->load($bodyData['operatory_id']);
    $epakShippingToUpdate = $this->epakShippingFactory->create()->load($bodyData['entity_id']);
    $epakShippingToUpdate->setOperatoryDescription($bodyData['operatory_id'] . ' - ' . $bodyData['operatory_description']);
    $epakShippingToUpdate->setShippingOriginAddressId($bodyData['shipping_address_id']);
    $epakShippingToUpdate->setOperatoryId($bodyData['operatory_id']);
    $epakShippingToUpdate->setCostCenterId($operative->getCostCenterId());
    if (isset($bodyData['shipping_origin_branch_postcode'])) {
      $epakShippingToUpdate->setShippingOriginBranchPostcode($bodyData['shipping_origin_branch_postcode']);
      $originDesc = 'Sucursal: ' . $bodyData['branch_address'];
      $epakShippingToUpdate->setWarehouseStreetAndNumber(null);
      $epakShippingToUpdate->setWarehouseCity(null);
      $epakShippingToUpdate->setWarehouseRegion(null);
      $epakShippingToUpdate->setWarehousePostalCode(null);
    } else {
      $epakShippingToUpdate->setWarehouseStreetAndNumber($bodyData['warehouse_street_and_number']);
      $epakShippingToUpdate->setWarehouseCity($bodyData['warehouse_city']);
      $epakShippingToUpdate->setWarehouseRegion($bodyData['warehouse_region']);
      $epakShippingToUpdate->setWarehousePostalCode($bodyData['warehouse_postal_code']);
      $originDesc = 'Puerta: ' . $bodyData['warehouse_street_and_number'] . ', ' . $bodyData['warehouse_city'] . ', ' . $bodyData['warehouse_region'];
      $epakShippingToUpdate->setShippingOriginBranchPostcode(null);
    }
    $epakShippingToUpdate->setOriginAddress($originDesc);
    $this->epakShippingRepository->save($epakShippingToUpdate);
    return $epakShippingToUpdate;
  }
}
