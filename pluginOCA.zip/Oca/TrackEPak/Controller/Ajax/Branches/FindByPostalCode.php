<?php

namespace Oca\TrackEPak\Controller\Ajax\Branches;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Oca\TrackEPak\Model\Ws\Ms\Adapter;
use Magento\Framework\App\Action\Action;

class FindByPostalCode extends Action implements HttpGetActionInterface
{

    protected $resultJsonFactory;
    protected $adapter;

    public function __construct(
        JsonFactory  $resultJsonFactory,
        Context $context
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $result  = $this->resultJsonFactory->create();
        $this->adapter = $this->_objectManager->create(Adapter::class);
        $postalCode = $this->_request->getParam('postalcode');
        $branches = $this->adapter->execGetCentrosImposicionConServiciosByCP($postalCode);
        if (!is_array($branches)) {
            $branches = [];
        }

        return $result->setData($branches);
    }
}
