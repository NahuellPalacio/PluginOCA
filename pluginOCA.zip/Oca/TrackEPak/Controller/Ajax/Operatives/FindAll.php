<?php

namespace Oca\TrackEPak\Controller\Ajax\Operatives;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Oca\TrackEPak\Api\OperatoryRepositoryInterface;
use Magento\Framework\App\Action\Action;

class FindAll extends Action implements HttpGetActionInterface
{

    protected $resultJsonFactory;
    protected $operatoryRepository;

    public function __construct(
        JsonFactory  $resultJsonFactory,
        OperatoryRepositoryInterface $operatoryRepository,
        Context $context
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->operatoryRepository = $operatoryRepository;
        parent::__construct($context);
    }

    public function execute()
    {
        $result  = $this->resultJsonFactory->create();
        $operatoriesListResult = $this->operatoryRepository->getActives();
        return $result->setData($operatoriesListResult);
    }
}
