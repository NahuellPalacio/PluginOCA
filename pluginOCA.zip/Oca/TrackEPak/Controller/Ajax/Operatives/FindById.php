<?php

namespace Oca\TrackEPak\Controller\Ajax\Operatives;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Oca\TrackEPak\Api\OperatoryRepositoryInterface;
use Magento\Framework\App\Action\Action;

/**
 * Catalog index page controller.
 */
class FindById extends Action implements HttpGetActionInterface
{
    /**
     * @var JsonFactory
     */
    protected $resultJsonFactory;
    protected $operatoryRepository;

    public function __construct(
        JsonFactory  $resultJsonFactory,
        Context $context,
        OperatoryRepositoryInterface $operatoryRepository
    ) {
        $this->operatoryRepository = $operatoryRepository;
        $this->resultJsonFactory = $resultJsonFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $result = $this->resultJsonFactory->create();

        $entityId = $this->_request->getParam('id');
        $operative = $this->operatoryRepository->get($entityId);

        return $result->setData($operative);
    }
}
