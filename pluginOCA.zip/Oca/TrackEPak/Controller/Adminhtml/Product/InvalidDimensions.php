<?php

namespace Oca\TrackEPak\Controller\Adminhtml\Product;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class InvalidDimensions extends Action
{
    protected $resultPageFactory;

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Oca_TrackEPak::invalid_dimensions');
        $resultPage->getConfig()->getTitle()->prepend(__('Productos sin dimensiones'));
        return $resultPage;
    }
}
