<?php

namespace Oca\TrackEPak\Controller\Adminhtml\Shipment;

use Magento\Backend\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Oca\TrackEPak\Controller\Adminhtml\Common as CommonController;
use Oca\TrackEPak\Model\Ws\Ms\Adapter;
use Oca\TrackEPak\Api\OperatoryRepositoryInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Api\ShipmentRepositoryInterface;

/**
 * Class GetCostCentersByShipment
 * @package Oca\TrackEPak\Controller\Adminhtml\Shipment
 */
class GetCostCentersByShipment extends CommonController
{
    protected $adapter;
    protected $operatoryRepository;
    protected $orderRepository;
    protected $shipmentRepository;
    protected $quoteRepository;

    public function __construct(
        Adapter $adapter,
        OperatoryRepositoryInterface $operatoryRepository,
        CartRepositoryInterface $quoteRepository,
        OrderRepositoryInterface $orderRepository,
        ShipmentRepositoryInterface $shipmentRepository,
        Registry $registry,
        PageFactory $resultPageFactory,
        Context $context
    ) {
        $this->adapter = $adapter;
        $this->quoteRepository = $quoteRepository;
        $this->orderRepository = $orderRepository;
        $this->shipmentRepository = $shipmentRepository;
        $this->operatoryRepository = $operatoryRepository;
        parent::__construct($registry, $resultPageFactory, $context);
    }

    /**
     * @return ResponseInterface|ResultInterface
     */
    public function execute()
    {
        $shipmentId = $this->getRequest()->getParam('shipment_id');
        $shipment = $this->shipmentRepository->get($shipmentId);
        $order = $this->orderRepository->get($shipment->getOrderId());
        $quote = $this->quoteRepository->get($order->getQuoteId());
        $operativeData = json_decode($quote->getData('oca_shipping_data'), true);

        $costCenters = $this->adapter->execGetCentroCostoPorOperativa($operativeData['operaty']);
        $operative = $this->operatoryRepository->getByCode($operativeData['operaty']);

        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $result = ['costCenters' => $costCenters, 'operative' => $operative];
        $resultJson->setData($result);
        return $resultJson;
    }
}
