<?php

namespace Oca\TrackEPak\Controller\Adminhtml\Oca\Operatory;

use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Oca\TrackEPak\Controller\Adminhtml\Common as CommonController;
use Oca\TrackEPak\Model\OperatoryFactory;
use Oca\TrackEPak\Model\OperatoryRepository;
use Oca\TrackEPak\Model\Ws\Ms\Adapter;

class Save extends CommonController
{
    protected $operatoryFactory;
    protected $operatoryRepository;
    protected $dataPersistor;
    protected $adapter;

    public function __construct(
        Context $context,
        Registry $registry,
        PageFactory $resultPageFactory,
        DataPersistorInterface $dataPersistor,
        OperatoryRepository $operatoryRepository,
        OperatoryFactory $operatoryFactory,
        Adapter $adapter
    ) {
        $this->dataPersistor = $dataPersistor;
        $this->adapter = $adapter;
        $this->operatoryFactory = $operatoryFactory;
        $this->operatoryRepository = $operatoryRepository;
        parent::__construct($registry, $resultPageFactory, $context);
    }

    private function extractCostCenterDescription($costCenters, $costCenterId) {
        foreach($costCenters as $costCenter) {
            if($costCenter['costCenterId'] == $costCenterId) {
                return $costCenter['costCenterId'] . ' - ' . $costCenter['street'] . ' ' . $costCenter['number'] . ', ' . $costCenter['city'] . ' (' . trim($costCenter['postalCode']) . ')';
            }
            return null;
        }
    }

    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        if ($data) {
            $id = $this->getRequest()->getParam('entity_id');

            if (isset($data['status']) && $data['status'] === 'true') {
                $data['status'] = 1;
            }
            if (empty($data['entity_id'])) {
                $data['entity_id'] = null;
            }

            if (!$id) {
                $model = $this->operatoryFactory->create();
            } else {
                try {
                    $model = $this->operatoryRepository->get($id);
                } catch (\Exception $e) {
                    $this->messageManager->addError(__('This Operatory no longer exists.'));
                    return $resultRedirect->setPath('*/*/');
                }
            }
            $model->setData($data);

            try {
                $costCenters = $this->adapter->execGetCentroCostoPorOperativa($data['code']);
                $costCenterDescription = $this->extractCostCenterDescription($costCenters, $data['cost_center_id']);
                $model->setCostCenterDescription($costCenterDescription);
                $this->operatoryRepository->save($model);
                $this->dataPersistor->clear(Edit::DATA_PERSISTOR_ID);

                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['entity_id' => $model->getId()]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the group.'));
            }

            $this->dataPersistor->set(Edit::DATA_PERSISTOR_ID, $model);
            return $resultRedirect->setPath('*/*/edit', ['entity_id' => $id]);
        }
        return $resultRedirect->setPath('*/*/');
    }
}
