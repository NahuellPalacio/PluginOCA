<?php

namespace Oca\TrackEPak\Controller\Adminhtml\Oca\Shipping;

use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Response\Http\FileFactory;
use Magento\Shipping\Model\Shipping\LabelGenerator;
use Magento\Sales\Api\ShipmentRepositoryInterface;
use Oca\TrackEPak\Controller\Adminhtml\Common as CommonController;

class PrintLabel extends CommonController
{
    protected $fileFactory;
    protected $pdfShipment;
    protected $shipmentRepository;
    protected $labelGenerator;

    public function __construct(
        Context $context,
        Registry $registry,
        PageFactory $resultPageFactory,
        FileFactory $fileFactory,
        LabelGenerator $labelGenerator,
        ShipmentRepositoryInterface $shipmentRepository
    ) {
        $this->fileFactory = $fileFactory;
        $this->shipmentRepository = $shipmentRepository;
        $this->labelGenerator = $labelGenerator;
        parent::__construct($registry, $resultPageFactory, $context);
    }

    public function execute()
    {
        $shipmentId = $this->getRequest()->getParam('shipment_id');
        $trackingNumber = $this->getRequest()->getParam('shipping_epak_id');

        $shipment = $this->shipmentRepository->get($shipmentId);
        $labelContent =  $shipment->getShippingLabel();
        
        if ($labelContent) {
            $labelsContent[] = $labelContent;
            $outputPdf = $this->labelGenerator->combineLabelsPdf($labelsContent);
            return $this->fileFactory->create(
                sprintf('etiqueta-OCA-%s.pdf', $trackingNumber),
                $outputPdf->render(),
                DirectoryList::VAR_DIR,
                'application/pdf'
            );
        }

        $this->messageManager->addError(__('No existe etiqueta para esta orden de envío.'));
        return $this->resultRedirectFactory->create()->setPath('*/*/');
        
    }
}
