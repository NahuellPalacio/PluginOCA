<?php

namespace Oca\TrackEPak\Controller\Adminhtml\Oca\Shipping;

use Magento\Backend\App\Action\Context;
use Oca\TrackEPak\Api\Data\EpakShippingInterface;
use Oca\TrackEPak\Api\EpakShippingRepositoryInterface;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Oca\TrackEPak\Controller\Adminhtml\Common as CommonController;

class Delete extends CommonController
{
    protected $epakShippingRepository;

    public function __construct(
        EpakShippingRepositoryInterface $epakShippingRepository,
        Registry $registry,
        PageFactory $resultPageFactory,
        Context $context
    ) {
        $this->epakShippingRepository = $epakShippingRepository;
        parent::__construct($registry, $resultPageFactory, $context);
    }

    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $id = $this->getRequest()->getParam(EpakShippingInterface::ENTITY_ID);
        if ($id) {
            try {
                $this->epakShippingRepository->delete($id);
                $this->messageManager->addSuccessMessage(__('Pre envío eliminado correctamente'));
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            }
        }
        return $resultRedirect->setPath('*/*/index');
    }
}
