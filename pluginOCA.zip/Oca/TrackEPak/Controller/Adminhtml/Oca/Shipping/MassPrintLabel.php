<?php

namespace Oca\TrackEPak\Controller\Adminhtml\Oca\Shipping;

use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Response\Http\FileFactory;
use Magento\Shipping\Model\Shipping\LabelGenerator;
use Magento\Sales\Api\ShipmentRepositoryInterface;
use Oca\TrackEPak\Controller\Adminhtml\Common as CommonController;
use Oca\TrackEPak\Model\ResourceModel\EpakShipping\CollectionFactory;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\FilterBuilder;


class MassPrintLabel extends CommonController
{
    protected $fileFactory;
    protected $pdfShipment;
    protected $shipmentRepository;
    protected $labelGenerator;
    protected $collectionFactory;
    protected $filter;
    protected $searchCriteriaBuilder;
    protected $filterBuilder;

    public function __construct(
        Context $context,
        Registry $registry,
        PageFactory $resultPageFactory,
        FileFactory $fileFactory,
        LabelGenerator $labelGenerator,
        Filter $filter,
        CollectionFactory $collectionFactory,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        FilterBuilder $filterBuilder,
        ShipmentRepositoryInterface $shipmentRepository
    ) {
        $this->fileFactory = $fileFactory;
        $this->shipmentRepository = $shipmentRepository;
        $this->labelGenerator = $labelGenerator;
        $this->filter = $filter;
        $this->collectionFactory = $collectionFactory;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->filterBuilder = $filterBuilder;
        parent::__construct($registry, $resultPageFactory, $context);
    }

    private function generateShipmentIdsFromCollection($collection) {
        $shipmentIds = [];
        foreach($collection as $item) {
            $shipmentIds[] = $item->getShipmentId();
        }
        return $shipmentIds;
    }

    private function createSearchCriteriaFromShipmentIds($shimentIds) {
        $filters[] = $this->filterBuilder->setField("entity_id")->setValue(implode(',', $shimentIds))->setConditionType("in")->create();
        $this->searchCriteriaBuilder->addFilters($filters);
        return $this->searchCriteriaBuilder->create();
    }

    public function execute()
    {        
        $collection = $this->filter->getCollection($this->collectionFactory->create());
        $shimentIds = $this->generateShipmentIdsFromCollection($collection);
        $searchCriteria = $this->createSearchCriteriaFromShipmentIds($shimentIds);
        $shipments = $this->shipmentRepository->getList($searchCriteria)->getItems();
        $labelsContent = [];

        foreach($shipments as $shipment) {
            $labelsContent[] = $shipment->getShippingLabel();
        }
        
        if ($labelsContent) {
            $outputPdf = $this->labelGenerator->combineLabelsPdf($labelsContent);
            return $this->fileFactory->create(
                sprintf('bundle-etiquetas-OCA-%s.pdf', date('Ymd')),
                $outputPdf->render(),
                DirectoryList::VAR_DIR,
                'application/pdf'
            );
        }

        $this->messageManager->addError(__('No pudieron generarse etiquetas.'));
        return $this->resultRedirectFactory->create()->setPath('*/*/');
        
    }
}
