<?php

namespace Oca\TrackEPak\Controller\Adminhtml\Oca\Shipping;

use Magento\Backend\App\Action\Context;
use Oca\TrackEPak\Api\Data\EpakShippingInterface;
use Oca\TrackEPak\Model\EpakShippingFactory;
use Oca\TrackEPak\Api\EpakShippingRepositoryInterface;
use Oca\TrackEPak\Model\Shipping\Oca as OcaShippingModel;
use Oca\TrackEPak\Logger\Logger;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Oca\TrackEPak\Controller\Adminhtml\Common as CommonController;

class Cancel extends CommonController
{

  protected $epakShippingRepository;
  protected $ocaShippingModel;
  protected $epakShippingFactory;
  protected $logger;

  public function __construct(
    Context $context,
    Registry $registry,
    PageFactory $resultPageFactory,
    Logger $logger,
    EpakShippingRepositoryInterface $epakShippingRepository,
    OcaShippingModel $ocaShippingModel,
    EpakShippingFactory $epakShippingFactory
  ) {
    $this->epakShippingRepository = $epakShippingRepository;
    $this->epakShippingFactory = $epakShippingFactory;
    $this->logger = $logger;
    $this->ocaShippingModel = $ocaShippingModel;
    parent::__construct($registry, $resultPageFactory, $context);
  }

  public function execute()
  {
    $epakShippingId = $this->getRequest()->getParam(EpakShippingInterface::ENTITY_ID);
    $this->logger->debug('Cancelando envío OCA Epak: ' . $epakShippingId);

    if ($epakShippingId) {
      try {
        $epakShipping = $this->epakShippingFactory->create()->load($epakShippingId);
        $result = $this->ocaShippingModel->cancelOcaShipment($epakShipping);

        if (!$result) {
          $this->messageManager->addErrorMessage(__('No se pudo cancelar el envío en OCA'));
        }

        $epakShipping->setShippingEpakId($epakShipping->getShippingEpakId() . ' (Envío cancelado)');
        $this->epakShippingRepository->save($epakShipping);

        $this->logger->debug('Cancelación de envio correcta');
        $this->messageManager->addSuccessMessage(__('El envío %1 fue cancelado correctamente.', $epakShipping->getShippingEpakId() ));
      } catch (\Exception $e) {
        $this->messageManager->addErrorMessage($e->getMessage());
        $this->logger->debug($e->getMessage());
      }
      $resultRedirect = $this->resultRedirectFactory->create();
      return $resultRedirect->setPath('*/*/index');
    }
  }
}
