<?php

namespace Oca\TrackEPak\Controller\Adminhtml\Oca\Shipping;

use Magento\Backend\App\Action\Context;
use Oca\TrackEPak\Logger\Logger;
use Oca\TrackEPak\Api\Data\EpakShippingInterface;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Oca\TrackEPak\Controller\Adminhtml\Common as CommonController;
use Oca\TrackEPak\Model\Shipping\Oca as OcaShippingModel;
use Magento\Ui\Component\MassAction\Filter;
use Oca\TrackEPak\Model\ResourceModel\EpakShipping\CollectionFactory;

class Confirm extends CommonController
{
    protected $ocaShippingModel;
    protected $collectionFactory;
    protected $logger;
    protected $filter;

    public function __construct(
        Logger $logger,
        Filter $filter,
        OcaShippingModel $ocaShippingModel,
        Registry $registry,
        PageFactory $resultPageFactory,
        CollectionFactory $collectionFactory,
        Context $context
    ) {
        $this->logger = $logger;
        $this->filter = $filter;
        $this->collectionFactory = $collectionFactory;
        $this->ocaShippingModel = $ocaShippingModel;
        parent::__construct($registry, $resultPageFactory, $context);
    }

    private function generateEpakShippingIdsFromCollection($collection)
    {
        $epakShippingIds = [];
        foreach($collection as $item) {
            $epakShippingIds[] = $item->getEntityId();
        }
        return $epakShippingIds;
    }

    public function execute()
    {
        $this->logger->debug('Confirmando envíos en Epak: ');

        $resultRedirect = $this->resultRedirectFactory->create();
        $epakShippingIds = null;
        $epakShippingId = $this->getRequest()->getParam(EpakShippingInterface::ENTITY_ID);

        if ($epakShippingId) {
            $epakShippingIds = array($epakShippingId);
        } else {
            $collection = $this->filter->getCollection($this->collectionFactory->create());
            $epakShippingIds = $this->generateEpakShippingIdsFromCollection($collection);
        }

        try {
            $result = $this->ocaShippingModel->confirmShipments($epakShippingIds);
            $this->messageManager->addSuccessMessage(__('Envios generadas correctamente: %1', count($result)));
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__('Error al crear el envío en OCA: %1, file:  %2, line: %3', $e->getMessage(), $e->getFile(), $e->getLine()));
        }


        return $resultRedirect->setPath('*/*/index');
    }

}
