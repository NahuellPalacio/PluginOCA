<?php

namespace Oca\TrackEPak\Model;

use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Oca\TrackEPak\Api\Data\OperatoryInterface;
use Oca\TrackEPak\Api\OperatoryRepositoryInterface;
use Oca\TrackEPak\Model\ResourceModel\Operatory as OperatoryResourceModel;

/**
 * Class OperatoryRepository
 * @package Oca\TrackEPak\Model
 */
class OperatoryRepository implements OperatoryRepositoryInterface
{
    /**
     * @var OperatoryFactory
     */
    protected $operatoryFactory;

    /**
     * @var OperatoryResourceModel
     */
    protected $operatoryResourceModel;
    protected $messageManager;

    /**
     * OperatoryRepository constructor.
     * @param OperatoryFactory $operatoryFactory
     * @param OperatoryResourceModel $operatoryResourceModel
     */
    public function __construct(
        \Magento\Framework\Message\ManagerInterface $messageManager,
        OperatoryFactory $operatoryFactory,
        OperatoryResourceModel $operatoryResourceModel
    ) {
        $this->messageManager = $messageManager;
        $this->operatoryFactory = $operatoryFactory;
        $this->operatoryResourceModel = $operatoryResourceModel;
    }

    /**
     * @inheritdoc
     */
    public function save(OperatoryInterface $operatory)
    {
        try {
            // Check if an operatory with the same number already exists
            $existingOperatory = $this->getByCode($operatory->getCode());
            if($operatory->getId()==null)
            {
                if ($existingOperatory && $existingOperatory['code'] == $operatory->getCode()) {
                    $this->messageManager->addErrorMessage(__('Ya existe una operatoria con numero %1', $operatory->getCode()));
                    return $operatory;
                }

            }
    
            $this->operatoryResourceModel->save($operatory);
            $this->messageManager->addSuccess(__('Operativa guardada correctamente'));
            return $operatory;
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__('Hubo un problema con la operatoria: %1', $e->getMessage()));
            return $operatory;
        }
    }
    

    /**
     * @inheritdoc
     */
    public function get($operatoryId)
    {
        /** @var Operatory $operatoryModel */
        $operatoryModel = $this->operatoryFactory->create();
        $this->operatoryResourceModel->load($operatoryModel, $operatoryId);
        if (!$operatoryModel->getId()) {
            throw new NoSuchEntityException(__('Operatory object with id "%1" does not exist.', $operatoryId));
        }

        return $operatoryModel;
    }

    public function getByCode($code)
    {
        return $this->operatoryResourceModel->getByCode($code);
    }

    /**
     * @inheritdoc
     */
    public function delete($operatoryId)
    {
        $this->operatoryResourceModel->deleteById($operatoryId);
    }

    public function getActives()
    {
        return $this->operatoryResourceModel->getActives();
    }
}
