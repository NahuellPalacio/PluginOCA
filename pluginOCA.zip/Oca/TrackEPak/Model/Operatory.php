<?php

namespace Oca\TrackEPak\Model;

use Magento\Framework\Model\AbstractModel;
use Oca\TrackEPak\Api\Data\OperatoryInterface;
use Oca\TrackEPak\Model\Config\Source\Status;
use Oca\TrackEPak\Model\ResourceModel\Operatory as OperatoryResourceModel;
use Oca\TrackEPak\Model\ResourceModel\Operatory\CollectionFactory as OperatoryCollectionFactory;

/**
 * Class Operatory
 * @package Oca\TrackEPak\Model
 */
class Operatory extends AbstractModel implements OperatoryInterface
{

    protected $operatoryCollectionFactory;

    public function __construct(
        OperatoryCollectionFactory $operatoryCollectionFactory,
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->operatoryCollectionFactory = $operatoryCollectionFactory;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * {@inheritDoc}
     */
    public function getEntityId()
    {
        return $this->getData(self::ENTITY_ID);
    }

    /**
     * {@inheritDoc}
     */
    public function setEntityId($entityId)
    {
        return $this->setData(self::ENTITY_ID, $entityId);
    }

    /**
     * @inheritDoc
     */
    public function getCode()
    {
        return $this->getData(self::CODE);
    }

    /**
     * @inheritDoc
     */
    public function setCode($code)
    {
        return $this->setData(self::CODE, $code);
    }

    /**
     * @inheritDoc
     */
    public function getCostCenterId()
    {
        return $this->getData(self::COST_CENTER_ID);
    }

    /**
     * @inheritDoc
     */
    public function setCostCenterId($costCenterId)
    {
        return $this->setData(self::COST_CENTER_ID, $costCenterId);
    }

    public function getCostCenterDescription()
    {
        return $this->getData(self::COST_CENTER_DESCRIPTION);
    }

    public function setCostCenterDescription($costCenterDescription)
    {
        return $this->setData(self::COST_CENTER_DESCRIPTION, $costCenterDescription);
    }

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getData(self::NAME);
    }

    /**
     * @inheritDoc
     */
    public function setName($name)
    {
        return $this->setData(self::NAME, $name);
    }
        /**
     * @inheritDoc
     */
    public function getCheckoutDescription()
    {
        return $this->getData(self::CHECKOUT_DESCRIPTION);
    }

    /**
     * @inheritDoc
     */
    public function setCheckoutDescription($checkoutDescription)
    {
        return $this->setData(self::CHECKOUT_DESCRIPTION, $checkoutDescription);
    }

    /**
     * {@inheritDoc}
     */
    public function getStatus()
    {
        return $this->getData(self::STATUS);
    }

    /**
     * {@inheritDoc}
     */
    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }

    /**
     * @inheritDoc
     */
    public function getIsDefault()
    {
        return $this->getData(self::IS_DEFAULT);
    }

    /**
     * @inheritDoc
     */
    public function setIsDefault($isDefault)
    {
        return $this->setData(self::IS_DEFAULT, $isDefault);
    }

    /**
     * @inheritDoc
     */
    public function getIsInsurance()
    {
        return $this->getData(self::IS_INSURANCE);
    }

    /**
     * @inheritDoc
     */
    public function setIsInsurance($isInsurance)
    {
        return $this->setData(self::IS_INSURANCE, $isInsurance);
    }

    /**
     * @inheritDoc
     */
    public function getType()
    {
        return $this->getData(self::TYPE);
    }

    /**
     * @inheritDoc
     */
    public function setType($type)
    {
        return $this->setData(self::TYPE, $type);
    }

    /**
     * {@inheritDoc}
     */
    public function getCreatedAt()
    {
        return $this->getData(self::CREATED_AT);
    }

    /**
     * {@inheritDoc}
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * {@inheritDoc}
     */
    public function getUpdatedAt()
    {
        return $this->getData(self::UPDATED_AT);
    }

    /**
     * {@inheritDoc}
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    public function getDefaultBranchDescription()
    {
        return $this->getData(self::DEFAULT_BRANCH_DESCRIPTION);
    }

    public function setDefaultBranchDescription($defaultBranchDescription)
    {
        return $this->setData(self::DEFAULT_BRANCH_DESCRIPTION, $defaultBranchDescription);
    }

    public function getDefaultBranchId()
    {
        return $this->getData(self::DEFAULT_BRANCH_ID);
    }

    public function setDefaultBranchId($defaultBranchId)
    {
        return $this->setData(self::DEFAULT_BRANCH_ID, $defaultBranchId);
    }

    public function getDefaultBranchPostalCode()
    {
        return $this->getData(self::DEFAULT_BRANCH_POSTAL_CODE);
    }

    public function setDefaultBranchPostalCode($defaultBranchPostalCode)
    {
        return $this->setData(self::DEFAULT_BRANCH_POSTAL_CODE, $defaultBranchPostalCode);
    }

    /**
     * Construct Function
     */
    protected function _construct()
    {
        $this->_init(OperatoryResourceModel::class);
    }

    /**
     * @return mixed
     */
    public function getDefaultToDoor()
    {
        $collection = $this->operatoryCollectionFactory->create();
        $collection->addFilterToDoor()
            ->addFieldToFilter('status', Status::ACTIVE)
            ->setOrder('is_default', 'DESC');

        return $collection->getFirstItem();
    }

    /**
     * @return mixed
     */
    public function getDefaultToBranch()
    {
        $collection = $this->operatoryCollectionFactory->create();
        $collection->addFilterToBranch()
            ->addFieldToFilter('status', Status::ACTIVE)
            ->setOrder('is_default', 'DESC');
        return $collection->getFirstItem();
    }

    public function getAllOperatories()
    {
        $collection = $this->operatoryCollectionFactory->create();
        $collection->addFieldToFilter('status', 1);
        return $collection->getItems();
    }
}
