<?php

namespace Oca\TrackEPak\Model;

use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Oca\TrackEPak\Api\Data\RequestHistoryInterface;
use Oca\TrackEPak\Api\RequestHistoryRepositoryInterface;
use Oca\TrackEPak\Model\ResourceModel\RequestHistory as RequestHistoryResourceModel;

/**
 * Class RequestHistoryRepository
 * @package Oca\TrackEPak\Model
 */
class RequestHistoryRepository implements RequestHistoryRepositoryInterface
{
    /**
     * @var RequestHistoryInterface
     */
    protected $requestHistoryInterfaceFactory;

    /**
     * @var RequestHistoryResourceModel
     */
    protected $requestHistoryResourceModel;

    /**
     * @param RequestHistoryInterface $requestHistoryInterfaceFactory
     * @param RequestHistoryResourceModel $requestHistoryResourceModel
     */
    public function __construct(
        RequestHistoryInterface $requestHistoryInterfaceFactory,
        RequestHistoryResourceModel $requestHistoryResourceModel
    ) {
        $this->requestHistoryInterfaceFactory = $requestHistoryInterfaceFactory;
        $this->requestHistoryResourceModel = $requestHistoryResourceModel;
    }

    /**
     * @inheritdoc
     */
    public function save(RequestHistoryInterface $requestHistory)
    {
        try {
            $this->requestHistoryResourceModel->save($requestHistory);
        } catch (\Exception $e) {
            throw new CouldNotSaveException(__($e->getMessage()));
        }
        return $requestHistory;
    }

    /**
     * @inheritdoc
     */
    public function get($requestHistoryId)
    {
        /** @var RequestHistoryInterface $requestHistoryModel */
        $requestHistoryModel = $this->requestHistoryInterfaceFactory->create();
        $this->requestHistoryResourceModel->load($requestHistoryModel, $requestHistoryId);
        if (!$requestHistoryModel->getId()) {
            throw new NoSuchEntityException(__('Request history object with id "%1" does not exist.', $requestHistoryId));
        }

        return $requestHistoryModel;
    }

    /**
     * @inheritdoc
     */
    public function delete($requestHistoryId)
    {
        $this->requestHistoryResourceModel->deleteById($requestHistoryId);
    }
}
