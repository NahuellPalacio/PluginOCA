<?php

namespace Oca\TrackEPak\Model\Carrier;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Message\ManagerInterface as MessageManagerInterface;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Address\RateRequest;
use Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory;
use Magento\Quote\Model\Quote\Address\RateResult\Method as AddressRateResultMethod;
use Magento\Quote\Model\Quote\Address\RateResult\MethodFactory;
use Magento\Shipping\Model\Carrier\AbstractCarrier;
use Magento\Shipping\Model\Carrier\CarrierInterface;
use Magento\Shipping\Model\Rate\Result as RateResult;
use Magento\Shipping\Model\Rate\ResultFactory;
use Magento\Shipping\Model\Shipment\RequestFactory;
use Magento\Shipping\Model\Tracking\Result as TrackingResult;
use Magento\Shipping\Model\Tracking\Result\Status as TrackingResultStatus;
use Oca\TrackEPak\Api\Data\OperatoryInterface;
use Oca\TrackEPak\Helper\Config;
use Oca\TrackEPak\Model\Carrier\Flatrate\ItemPriceCalculator;
use Oca\TrackEPak\Model\Operatory;
use Oca\TrackEPak\Service\GetShippingPrice as SoapCalculateShipping;
use Psr\Log\LoggerInterface;

class OcaShipping extends AbstractCarrier implements CarrierInterface
{
    const CARRIER_CODE = 'ocashipping';

    protected $_code = self::CARRIER_CODE;
    private $soapCalculateShipping;
    private $rateResultFactory;
    private $rateMethodFactory;
    private $itemPriceCalculator;
    private $requestFactory;
    private $messageManagerInterface;
    private $trackingResult;
    private $trackingResultStatus;
    private $operatoryModel;
    private $configHelper;
    protected $logger;
    protected $quote;

    public function __construct(
        Config $configHelper,
        TrackingResultStatus $trackingResultStatus,
        TrackingResult $trackingResult,
        MessageManagerInterface $messageManagerInterface,
        RequestFactory $requestFactory,
        SoapCalculateShipping $soapCalculateShipping,
        ScopeConfigInterface $scopeConfig,
        ErrorFactory $rateErrorFactory,
        LoggerInterface $logger,
        ResultFactory $rateResultFactory,
        MethodFactory $rateMethodFactory,
        ItemPriceCalculator $itemPriceCalculator,
        Operatory $operatoryModel,
        Quote $quote,
        array $data = []
    ) {
        parent::__construct($scopeConfig, $rateErrorFactory, $logger, $data);
        $this->soapCalculateShipping = $soapCalculateShipping;
        $this->rateResultFactory = $rateResultFactory;
        $this->rateMethodFactory = $rateMethodFactory;
        $this->itemPriceCalculator = $itemPriceCalculator;
        $this->requestFactory = $requestFactory;
        $this->messageManagerInterface = $messageManagerInterface;
        $this->trackingResult = $trackingResult;
        $this->trackingResultStatus = $trackingResultStatus;
        $this->operatoryModel = $operatoryModel;
        $this->configHelper = $configHelper;
        $this->quote = $quote;
    }

    public function collectRates(RateRequest $request)
    {
        if (!$this->isShowOcaShippingMethod() || !$request->getDestPostcode()) {
            return false;
        }

        $isUsingFlatRateToCalculate = $this->getConfigData('is_using_flat_rate');

        // Consolidar dimensiones
        $consolidatedDimensions = $this->consolidateDimensions($request->getAllItems());

        if (!$consolidatedDimensions) {
            $this->messageManagerInterface->addErrorMessage('No se pueden calcular las dimensiones del envío. Por favor, verifique que todos los productos tengan las dimensiones cargadas.');
            return false;
        }

        $this->_logger->info('OCA collect rates');

        $operatives = $this->operatoryModel->getAllOperatories();


        /** @var RateResult $result */
        $result = $this->rateResultFactory->create();

        foreach ($operatives as $operatory) {
            $data = $operatory->getData();
            $shippingPrice = $this->soapCalculateShipping->handleApi($request, $consolidatedDimensions,$data);
            if ($shippingPrice === false) {
                continue;
            }
            $method = $this->createResultMethod($shippingPrice,$operatory);
            $result->append($method);

        }


        return $result;
    }

    private function consolidateDimensions($items)
    {
        $maxHeight = 0;
        $maxWidth = 0;
        $maxDepth = 0;

        foreach ($items as $item) {
            if ($item->getProduct()->isVirtual() || $item->getParentItem()) {
                continue;
            }

            $product = $item->getProduct();
            $product->load($product->getId());

            $height = (float) $product->getData('oca_alto');
            $width = (float) $product->getData('oca_ancho');
            $depth = (float) $product->getData('oca_largo');

            if (!$height || !$width || !$depth) {
                return false; // Si alguna dimensión falta, retornar falso
            }

            $maxHeight = max($maxHeight, $height);
            $maxWidth += $width;
            $maxDepth = max($maxDepth, $depth);
        }

        $volume = ($maxHeight * $maxWidth * $maxDepth) / 1000000;

        return [
            'height' => $maxHeight,
            'width' => $maxWidth,
            'depth' => $maxDepth,
            'volume' => $volume,
        ];
    }

    private function isShowOcaShippingMethod()
    {
        if (!$this->getConfigFlag('active')) {
            return false;
        }

        /** @var OperatoryInterface $toDoorItem */
        $toDoorItem = $this->operatoryModel->getDefaultToDoor();
        /** @var OperatoryInterface $toBranchItem */
        $toBranchItem = $this->operatoryModel->getDefaultToBranch();

        if (!$toDoorItem->getEntityId() && !$toBranchItem->getEntityId()) {
            return false;
        }

        return true;
    }

    public function isTrackingAvailable()
    {
        return true;
    }

    private function getShippingPrice(RateRequest $request, $freeBoxes)
    {
        $shippingPrice = false;

        $configPrice = $this->getConfigData('shipping_cost');

        if ($this->getConfigData('type') === 'O') {
            $shippingPrice = $this->itemPriceCalculator->getShippingPricePerOrder($request, $configPrice, $freeBoxes);
        } elseif ($this->getConfigData('type') === 'I') {
            $shippingPrice = $this->itemPriceCalculator->getShippingPricePerItem($request, $configPrice, $freeBoxes);
        }

        $shippingPrice = $this->getFinalPriceWithHandlingFee($shippingPrice);

        if ($shippingPrice !== false && $request->getPackageQty() == $freeBoxes) {
            $shippingPrice = '0.00';
        }
        return $shippingPrice;
    }

    private function getFreeBoxesCount(RateRequest $request)
    {
        $freeBoxes = 0;
        if ($request->getAllItems()) {
            foreach ($request->getAllItems() as $item) {
                if ($item->getProduct()->isVirtual() || $item->getParentItem()) {
                    continue;
                }

                if ($item->getHasChildren() && $item->isShipSeparately()) {
                    $freeBoxes += $this->getFreeBoxesCountFromChildren($item);
                } elseif ($item->getFreeShipping()) {
                    $freeBoxes += $item->getQty();
                }
            }
        }
        return $freeBoxes;
    }

    private function getFreeBoxesCountFromChildren($item)
    {
        $freeBoxes = 0;
        foreach ($item->getChildren() as $child) {
            if ($child->getFreeShipping() && !$child->getProduct()->isVirtual()) {
                $freeBoxes += $item->getQty() * $child->getQty();
            }
        }
        return $freeBoxes;
    }

    public function getAllowedMethods()
    {
        return [self::CARRIER_CODE => $this->getConfigData('name')];
    }

    private function createResultMethod($shippingPrice, $operative)
    {
        /** @var AddressRateResultMethod $method */
        $method = $this->rateMethodFactory->create();

        $method->setCarrier(self::CARRIER_CODE);
        $method->setCarrierTitle($this->getConfigData('title'));

        $method->setMethod(self::CARRIER_CODE."_".$operative->getCode());
        $method->setMethodTitle($operative->getCheckoutDescription());

        $method->setPrice($shippingPrice);
        $method->setCost($shippingPrice);
        return $method;
    }

    public function isShippingLabelsAvailable()
    {
        return false;
    }

    public function getTracking($trackings)
    {
        if (!is_array($trackings)) {
            $trackings = [$trackings];
        }

        foreach ($trackings as $tracking) {
            $this->trackingResultStatus->setCarrier($this->getConfigData('code'));
            $this->trackingResultStatus->setCarrierTitle($this->getConfigData('title'));
            $this->trackingResultStatus->setTracking($tracking);
            $this->trackingResultStatus->setPopup(1);
            $this->trackingResultStatus->setUrl($this->configHelper->getTrackingUrl() . $tracking);
            $this->trackingResult->append($this->trackingResultStatus);
        }

        return $this->trackingResult;
    }

    public function getTrackingInfo($tracking)
    {
        $result = $this->getTracking($tracking);

        if ($result instanceof TrackingResult) {
            if ($trackings = $result->getAllTrackings()) {
                return $trackings[0];
            }
        } elseif (is_string($result) && !empty($result)) {
            return $result;
        }

        return false;
    }
}
