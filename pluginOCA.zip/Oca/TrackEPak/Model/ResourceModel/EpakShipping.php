<?php

namespace Oca\TrackEPak\Model\ResourceModel;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class EpakShipping
 * @package Oca\TrackEPak\Model\ResourceModel
 */
class EpakShipping extends AbstractDb
{
    const TABLE_NAME = 'oca_track_epak_shipping';
    const ENTITY_ID = 'entity_id';

    /**
     * Resource initialisation
     * @codingStandardsIgnoreStart
     */
    protected function _construct()
    {
        $this->_init(self::TABLE_NAME, self::ENTITY_ID);
    }

    /**
     * @param $id
     * @throws LocalizedException
     */
    public function deleteById($id)
    {
        $this->getConnection()->delete(
            $this->getMainTable(),
            ['entity_id = ?' => $id]
        );
    }

    /**
     * @param $ids
     * @throws LocalizedException
     */
    public function deleteByIds($ids)
    {
        $this->getConnection()->delete(
            $this->getMainTable(),
            ['entity_id = in (?)' => $ids]
        );
    }

    /**
     * @param int $id
     * @return array
     * @throws LocalizedException
     */
    public function getById($id)
    {
        $select = $this->getConnection()->select()
            ->from($this->getMainTable())
            ->where('entity_id = ?', $id)
            ->limit(1);
        return $this->getConnection()->fetchRow($select);
    }

    /**
     * @param int $orderId
     * @return array
     * @throws LocalizedException
     */
    public function getByOrderId($orderId)
    {
        $select = $this->getConnection()->select()
            ->from($this->getMainTable())
            ->where('order_id = ?', $orderId)
            ->limit(1);
        return $this->getConnection()->fetchRow($select);
    }

}
