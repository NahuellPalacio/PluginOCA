<?php
namespace Oca\TrackEPak\Model\ResourceModel\EpakShipping;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Oca\TrackEPak\Api\Data\EpakShippingInterface;
use Oca\TrackEPak\Model\EpakShipping as EpakShippingModel;
use Oca\TrackEPak\Model\ResourceModel\EpakShipping as EpakShippingResourceModel;

/**
 * Class Collection
 * @package Oca\TrackEPak\Model\ResourceModel\EpakShipping
 */
class Collection extends AbstractCollection
{
    protected $_idFieldName = EpakShippingInterface::ENTITY_ID;

    protected function _construct()
    {
        $this->_init(EpakShippingModel::class, EpakShippingResourceModel::class);
    }

}
