<?php
namespace Oca\TrackEPak\Model\ResourceModel\Operatory;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Oca\TrackEPak\Api\Data\OperatoryInterface;
use Oca\TrackEPak\Model\Config\Source\OperatoryType;
use Oca\TrackEPak\Model\Operatory as OperatoryModel;
use Oca\TrackEPak\Model\ResourceModel\Operatory as OperatoryResourceModel;

/**
 * Class Collection
 * @package Oca\TrackEPak\Model\ResourceModel\Operatory
 */
class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = OperatoryInterface::ENTITY_ID;

    /**
     * Collection initialisation
     */

    protected function _construct()
    {
        $this->_init(OperatoryModel::class, OperatoryResourceModel::class);
    }

    /**
     * Filter to Door
     *
     * @return Collection
     */
    public function addFilterToDoor()
    {
        return $this->addFieldToFilter(OperatoryInterface::TYPE, ['in' => OperatoryType::GROUP_TO_DOOR]);
    }

    /**
     * Filter to Branch
     *
     * @return Collection
     */
    public function addFilterToBranch()
    {
        return $this->addFieldToFilter(OperatoryInterface::TYPE, ['in' => OperatoryType::GROUP_TO_BRANCH]);
    }
}
