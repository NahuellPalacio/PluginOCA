<?php
namespace Oca\TrackEPak\Model\ResourceModel;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class Operatory
 * @package Oca\TrackEPak\Model\ResourceModel
 */
class Operatory extends AbstractDb
{
    const TABLE_NAME = 'oca_track_epak_operatory';
    const ENTITY_ID = 'entity_id';

    /**
     * Resource initialisation
     * @codingStandardsIgnoreStart
     */
    protected function _construct()
    {
        $this->_init(self::TABLE_NAME, self::ENTITY_ID);
    }

    /**
     * @param $id
     * @throws LocalizedException
     */
    public function deleteById($id)
    {
        $this->getConnection()->delete(
            $this->getMainTable(),
            ['entity_id = ?' => $id]
        );
    }

    /**
     * @param int $code
     * @return array
     * @throws LocalizedException
     */
    public function getByCode($code)
    {
        $select = $this->getConnection()->select()
            ->from($this->getMainTable())
            ->where('code = ?', $code)
            ->limit(1);
        return $this->getConnection()->fetchRow($select);
    }

    /**
     * @param $ids
     * @throws LocalizedException
     */
    public function deleteByIds($ids)
    {
        $this->getConnection()->delete(
            $this->getMainTable(),
            ['entity_id = in (?)' => $ids]
        );
    }

    public function getActives()
    {
        $select = $this->getConnection()->select()
            ->where('status = ?', 1)
            ->from($this->getMainTable());
        return $this->getConnection()->fetchAll($select);
    }
}
