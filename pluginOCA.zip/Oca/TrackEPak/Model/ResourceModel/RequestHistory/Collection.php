<?php
namespace Oca\TrackEPak\Model\ResourceModel\RequestHistory;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Oca\TrackEPak\Api\Data\RequestHistoryInterface;
use Oca\TrackEPak\Model\RequestHistory as RequestHistoryModel;
use Oca\TrackEPak\Model\ResourceModel\RequestHistory as RequestHistoryResourceModel;

/**
 * Class Collection
 * @package Oca\TrackEPak\Model\ResourceModel\RequestHistory
 */
class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = RequestHistoryInterface::ENTITY_ID;

    /**
     * Collection initialisation
     */
    protected function _construct()
    {
        $this->_init(RequestHistoryModel::class, RequestHistoryResourceModel::class);
    }
}
