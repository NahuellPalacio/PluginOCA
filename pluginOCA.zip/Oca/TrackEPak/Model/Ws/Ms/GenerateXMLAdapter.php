<?php

namespace Oca\TrackEPak\Model\Ws\Ms;

use SimpleXMLElement;

class GenerateXMLAdapter
{

    private function createBaseXML($nroCuenta)
    {
        // Tiene que estar identado asi para que pueda leerlo como XML
        $xmlstrBase = <<<XML
<?xml version="1.0" encoding="ISO-8859-1" ?><ROWS><cabecera ver="2.0" nrocuenta="$nroCuenta" origen="MAG"/><origenes></origenes></ROWS>
XML;
        return new SimpleXMLElement($xmlstrBase);
    }

    private function addOrigenNode($origenes, $shippingSourceAddress)
    {
        $origen = $origenes->addChild('origen');
        foreach ($shippingSourceAddress as $clave => $valor) {
            $string = iconv('UTF-8', 'ASCII//TRANSLIT', (string) $valor);
            $string = preg_replace('/[^a-zA-Z0-9\s]/', '', $string);

            $origen->addAttribute($clave, (string) ($string ?? ""));
        }

        return $origen;
    }

    private function addEnviosNode($origen, $operativeCode, $nroRemito)
    {
        $envios = $origen->addChild('envios');
        $envio = $envios->addChild('envio');
        $envio->addAttribute('idoperativa', (string) $operativeCode);
        $envio->addAttribute('nroremito', (string) $nroRemito);

        return $envio;
    }

    private function addDestinatarioNode($envio, $shippingDesAddress)
    {
        $destinatario = $envio->addChild('destinatario');

        foreach ($shippingDesAddress as $clave => $valor) {
            $string = iconv('UTF-8', 'ASCII//TRANSLIT', (string) $valor);
            $string = preg_replace('/[^a-zA-Z0-9\s]/', '', $string);
            $destinatario->addAttribute($clave, ($string ?? ""));
        }

        return $destinatario;
    }

    public function buildXmlDataForCreateShipment($shipmentToConfirm, $nroCuenta)
    {
        $ROWS = $this->createBaseXML($nroCuenta); // ROWS es el tag XML que hay que enviar.
        $origen = $this->addOrigenNode($ROWS->origenes, $shipmentToConfirm['sourceAddress']);
        $envio = $this->addEnviosNode($origen, $shipmentToConfirm['operativeCode'], $shipmentToConfirm['order']->getIncrementId());
        $origen = $this->addDestinatarioNode($envio, $shipmentToConfirm['destinationAddress']);
        $shipmentItems = $shipmentToConfirm['order']->getAllItems();
        $this->addPaquetesNode($shipmentItems, $shipmentToConfirm['packages'], $shipmentToConfirm['packagesNumber'], $envio);

        return $ROWS->asXML();
    }

    private function addPaquetesNode($shipmentItems, $packages, $packagesNumber, $envio)
    {
        if ($packagesNumber) {
            return $this->createCustomPackageNode($shipmentItems, $packages, $packagesNumber, $envio);
        }

        return $this->createDefaultPackageNode($shipmentItems, $packages, $envio);
    }

    private function createDefaultPackageNode($shipmentItems, $quotePackages, $envio)
    {
        $paquetes = null;
        $paquetes = $envio->addChild('paquetes');

        foreach ($shipmentItems as $item) {
            $package = $this->findPackageForItem($item->getProductId(), $quotePackages);

            $data_product = $item->getProduct();
            $heightCm = (float) $data_product->getOcaAlto() ?? 100 * $package['alto'];
            $lengthCm = (float) $data_product->getOcaLargo() ?? 100 * $package['ancho'];
            $widthCm = (float) $data_product->getOcaAncho() ?? 100 * $package['largo'];

            $weightKg = round($package['peso'], 2);
            $customsValue = $package['valor'] * $item->getQty();

            $paquete = $paquetes->addChild('paquete');
            $paquete->addAttribute('alto', (string) $heightCm);
            $paquete->addAttribute('largo', (string) $lengthCm);
            $paquete->addAttribute('ancho', (string) $widthCm);
            $paquete->addAttribute('peso', (string) $weightKg);
            $paquete->addAttribute('valor', (string) $customsValue);
            $paquete->addAttribute('cant', 1);
        }
        return $paquetes;
    }
    // foreach ($shipmentItems as $item) {
    //     $data_product = $item->getProduct();
    //     $package = $this->findPackageForItem($item->getProductId(), $quotePackages);

    //     $oca_alto = (float) $data_product->getOcaAlto() ?? ceil(100 * $package['alto'] / $packagesNumber);
    //     $oca_largo = (float) $data_product->getOcaLargo() ?? ceil(100 * $package['ancho'] / $packagesNumber);
    //     $oca_ancho = (float) $data_product->getOcaAncho() ?? ceil(100 * $package['largo'] / $packagesNumber);
    //     $oca_peso = (float) ($item->getQty() * $package['peso']);

    //     $paquete = $paquetes->addChild('paquete');
    //     $paquete->addAttribute('alto', (string) $oca_alto);
    //     $paquete->addAttribute('largo', (string) $oca_largo);
    //     $paquete->addAttribute('ancho', (string) $oca_ancho);
    //     $paquete->addAttribute('peso', (string) $oca_peso);
    //     $customsValue = ceil($package['valor'] * $item->getQty());
    //     $paquete->addAttribute('valor', (string) $customsValue);

    //     $paquete->addAttribute('cant', (string) $packagesNumber);
    // }
    private function createCustomPackageNode($shipmentItems, $quotePackages, $packagesNumber, $envio)
    {
        //dd("cc");
        $heightCm = 0;
        $lengthCm = 0;
        $widthCm = 0;
        $weightKg = 0;
        $customsValue = 0;

        foreach ($shipmentItems as $item) {
            $package = $this->findPackageForItem($item->getProductId(), $quotePackages);

            $data_product = $item->getProduct();
            $heightCmProduct = (float) $data_product->getOcaAlto() ?? 100 * $package['alto'];
            $lengthCmProduct = (float) $data_product->getOcaLargo() ?? 100 * $package['ancho'];
            $widthCmProduct = (float) $data_product->getOcaAncho() ?? 100 * $package['largo'];

            $heightCm += ceil($heightCmProduct / $packagesNumber);
            $lengthCm += ceil($lengthCmProduct / $packagesNumber);
            $widthCm += ceil($widthCmProduct / $packagesNumber);
            $weightKg += round($package['peso'] / $packagesNumber, 2);
            $customsValue += ceil($package['valor'] * $item->getQty() / $packagesNumber);
        }

        $paquetes = $envio->addChild('paquetes');
        $paquete = $paquetes->addChild('paquete');
        $paquete->addAttribute('alto', (string) $heightCm);
        $paquete->addAttribute('largo', (string) $lengthCm);
        $paquete->addAttribute('ancho', (string) $widthCm);
        $paquete->addAttribute('peso', (string) $weightKg);
        $paquete->addAttribute('valor', (string) $customsValue);
        $paquete->addAttribute('cant', (string) $packagesNumber);

        return $paquetes;
    }

    private function findPackageForItem($itemId, $quotePackages)
    {
        foreach ($quotePackages as $package) {
            if ($package['product_id'] === $itemId) {
                return $package;
            }
        }
        return null;
    }

}
