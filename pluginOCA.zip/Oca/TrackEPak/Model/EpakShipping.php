<?php

namespace Oca\TrackEPak\Model;

use Magento\Framework\Model\AbstractModel;
use Oca\TrackEPak\Api\Data\EpakShippingInterface;
use Oca\TrackEPak\Model\ResourceModel\EpakShipping as EpakShippingResourceModel;

/**
 * Class EpakShipping
 * @package Oca\TrackEPak\Model
 */
class EpakShipping extends AbstractModel implements EpakShippingInterface
{
    /**
     * Construct Function
     */
    protected function _construct()
    {
        $this->_init(EpakShippingResourceModel::class);
    }

    /**
     * {@inheritDoc}
     */
    public function getEntityId()
    {
        return $this->getData(self::ENTITY_ID);
    }

    /**
     * {@inheritDoc}
     */
    public function setEntityId($entityId)
    {
        return $this->setData(self::ENTITY_ID, $entityId);
    }

    /**
     * @inheritDoc
     */
    public function getOrderId()
    {
        return $this->getData(self::ORDER_ID);
    }

    /**
     * @inheritDoc
     */
    public function setOrderId($orderId)
    {
        return $this->setData(self::ORDER_ID, $orderId);
    }

    /**
     * @inheritDoc
     */
    public function getShipmentId()
    {
        return $this->getData(self::SHIPMENT_ID);
    }

    /**
     * @inheritDoc
     */
    public function setShipmentId($shipmentId)
    {
        return $this->setData(self::SHIPMENT_ID, $shipmentId);
    }

    /**
     * @inheritDoc
     */
    public function getIncrementId()
    {
        return $this->getData(self::INCREMENT_ID);
    }

    /**
     * @inheritDoc
     */
    public function setIncrementId($incrementId)
    {
        return $this->setData(self::INCREMENT_ID, $incrementId);
    }

    /**
     * {@inheritDoc}
     */
    public function getCreatedAt()
    {
        return $this->getData(self::CREATED_AT);
    }

    /**
     * {@inheritDoc}
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * {@inheritDoc}
     */
    public function getShippingEpakId()
    {
        return $this->getData(self::SHIPPING_EPAK_ID);
    }

    /**
     * {@inheritDoc}
     */
    public function setShippingOriginAddressId($shippingOriginAddressId)
    {
        return $this->setData(self::SHIPPING_ORIGIN_ADDRESS_ID, $shippingOriginAddressId);
    }

    /**
     * {@inheritDoc}
     */
    public function getShippingOriginBranchPostcode()
    {
        return $this->getData(self::SHIPPING_ORIGIN_BRANCH_POSTCODE);
    }

    /**
     * {@inheritDoc}
     */
    public function setShippingOriginBranchPostcode($shippingOriginBranchPostcode)
    {
        return $this->setData(self::SHIPPING_ORIGIN_BRANCH_POSTCODE, $shippingOriginBranchPostcode);
    }

    /**
     * {@inheritDoc}
     */
    public function getShippingOriginAddressId()
    {
        return $this->getData(self::SHIPPING_ORIGIN_ADDRESS_ID);
    }

    /**
     * {@inheritDoc}
     */
    public function setShippingEpakId($shippingEpakId)
    {
        return $this->setData(self::SHIPPING_EPAK_ID, $shippingEpakId);
    }

    /**
     * {@inheritDoc}
     */
    public function getShippingEpakWithdrawalId()
    {
        return $this->getData(self::SHIPPING_EPAK_WITHDRAWAL_ID);
    }

    /**
     * {@inheritDoc}
     */
    public function setShippingEpakWithdrawalId($shippingEpakWithdrawalId)
    {
        return $this->setData(self::SHIPPING_EPAK_WITHDRAWAL_ID, $shippingEpakWithdrawalId);
    }

    /**
     * {@inheritDoc}
     */
    public function getOperatoryDescription()
    {
        return $this->getData(self::OPERATORY_DESCRIPTION);
    }

    /**
     * {@inheritDoc}
     */
    public function setOperatoryDescription($operatoryDescription)
    {
        return $this->setData(self::OPERATORY_DESCRIPTION, $operatoryDescription);
    }

    public function getWarehouseStreetAndNumber()
    {
        return $this->getData(self::WAREHOUSE_STREET_AND_NUMBER);
    }

    public function setWarehouseStreetAndNumber($warehouseStreetAndNumber)
    {
        return $this->setData(self::WAREHOUSE_STREET_AND_NUMBER, $warehouseStreetAndNumber);
    }

    public function getWarehouseCity()
    {
        return $this->getData(self::WAREHOUSE_CITY);
    }

    public function setWarehouseCity($warehouseCity)
    {
        return $this->setData(self::WAREHOUSE_CITY, $warehouseCity);
    }

    public function getWarehouseRegion()
    {
        return $this->getData(self::WAREHOUSE_REGION);
    }

    public function setWarehouseRegion($warehouseRegion)
    {
        return $this->setData(self::WAREHOUSE_REGION, $warehouseRegion);
    }

    public function getWarehousePostalCode()
    {
        return $this->getData(self::WAREHOUSE_POSTAL_CODE);
    }

    public function setWarehousePostalCode($warehousePostalCode)
    {
        return $this->setData(self::WAREHOUSE_POSTAL_CODE, $warehousePostalCode);
    }

    /**
     * {@inheritDoc}
     */
    public function getOperatoryId()
    {
        return $this->getData(self::OPERATORY_ID);
    }

    /**
     * {@inheritDoc}
     */
    public function setOperatoryId($operatoryId)
    {
        return $this->setData(self::OPERATORY_ID, $operatoryId);
    }

    /**
     * {@inheritDoc}
     */
    public function getOriginAddress()
    {
        return $this->getData(self::ORIGIN_ADDRESS);
    }

    /**
     * {@inheritDoc}
     */
    public function setOriginAddress($originAddress)
    {
        return $this->setData(self::ORIGIN_ADDRESS, $originAddress);
    }

    public function getPackagesNumber()
    {
        return $this->getData(self::PACKAGES_NUMBER);
    }

    public function setPackagesNumber($packagesNumber) 
    {
        return $this->setData(self::PACKAGES_NUMBER, $packagesNumber);
    }

    public function getCostCenterId()
    {
        return $this->getData(self::COST_CENTER_ID);
    }

    public function setCostCenterId($costCenterId)
    {
        return $this->setData(self::COST_CENTER_ID, $costCenterId);
    }

    public function getCostCenterDescription()
    {
        return $this->getData(self::COST_CENTER_DESCRIPTION);
    }

    public function setCostCenterDescription($costCenterDescription)
    {
        return $this->setData(self::COST_CENTER_DESCRIPTION, $costCenterDescription);
    }

}
