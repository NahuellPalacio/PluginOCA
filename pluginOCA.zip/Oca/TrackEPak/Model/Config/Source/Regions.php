<?php

namespace Oca\TrackEPak\Model\Config\Source;

use Magento\Framework\Data\OptionSourceInterface;
use Magento\Framework\DataObject;

class Regions extends DataObject implements OptionSourceInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        
        return [
            [
                'value' => 'Buenos Aires',
                'label' => 'Buenos Aires'
            ],
            [
                'value' => 'Capital Federal',
                'label' => 'Capital Federal'
            ],
            [
                'value' => 'Catamarca',
                'label' => 'Catamarca'
            ],
            [
                'value' => 'Chaco',
                'label' => 'Chaco'
            ],
            [
                'value' => 'Chubut',
                'label' => 'Chubut'
            ],
            [
                'value' => 'Cordoba',
                'label' => 'Córdoba'
            ],
            [
                'value' => 'Corrientes',
                'label' => 'Corrientes'
            ],
            [
                'value' => 'Entre Rios',
                'label' => 'Entre Ríos'
            ],
            [
                'value' => 'Formosa',
                'label' => 'Formosa'
            ],
            [
                'value' => 'Jujuy',
                'label' => 'Jujuy'
            ],
            [
                'value' => 'La Pampa',
                'label' => 'La Pampa'
            ],
            [
                'value' => 'La Rioja',
                'label' => 'La Rioja'
            ],
            [
                'value' => 'Mendoza',
                'label' => 'Mendoza'
            ],
            [
                'value' => 'Misiones',
                'label' => 'Misiones'
            ],
            [
                'value' => 'Neuquen',
                'label' => 'Neuquén'
            ],
            [
                'value' => 'Rio Negro',
                'label' => 'Río Negro'
            ],
            [
                'value' => 'Salta',
                'label' => 'Salta'
            ],
            [
                'value' => 'San Juan',
                'label' => 'San Juan'
            ],
            [
                'value' => 'San Luis',
                'label' => 'San Luís'
            ],
            [
                'value' => 'Santa Cruz',
                'label' => 'Santa Cruz'
            ],
            [
                'value' => 'Santa Fe',
                'label' => 'Santa Fe'
            ],
            [
                'value' => 'Santiago del Estero',
                'label' => 'Santiago del Estero'
            ],
            [
                'value' => 'Tierra del Fuego',
                'label' => 'Tierra del Fuego'
            ],
            [
                'value' => 'Tucuman',
                'label' => 'Tucumán'
            ]
        ];
    }
}
