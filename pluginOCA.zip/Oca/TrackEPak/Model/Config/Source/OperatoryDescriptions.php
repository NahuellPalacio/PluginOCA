<?php

namespace Oca\TrackEPak\Model\Config\Source;

use Magento\Framework\Data\OptionSourceInterface;
use Magento\Framework\DataObject;


class OperatoryDescriptions extends DataObject implements OptionSourceInterface
{

    const DESCRIPTIONS = [
    'OCA - Envío a domicilio', 'OCA - Envío a sucursal',
    ];
 
    public function toOptionArray()
    {
        $options = [];
        foreach (self::DESCRIPTIONS as $type => $label) {
            $options[] = ['value' => $label, 'label' => __($label)];
        }

        return $options;
    }
}
