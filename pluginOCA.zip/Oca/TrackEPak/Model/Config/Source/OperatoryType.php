<?php

namespace Oca\TrackEPak\Model\Config\Source;

use Magento\Framework\Data\OptionSourceInterface;
use Magento\Framework\DataObject;


class OperatoryType extends DataObject implements OptionSourceInterface
{
    const TYPE_DOOR_TO_DOOR = 1;
    const TYPE_BRANCH_TO_DOOR = 2;
    const TYPE_DOOR_TO_BRANCH = 3;
    const TYPE_BRANCH_TO_BRANCH = 4;
    const GROUP_TO_DOOR = [
        self::TYPE_DOOR_TO_DOOR,
        self::TYPE_BRANCH_TO_DOOR,
    ];
    const GROUP_TO_BRANCH = [
        self::TYPE_DOOR_TO_BRANCH,
        self::TYPE_BRANCH_TO_BRANCH,
    ];
    const GROUP_FROM_DOOR = [
        self::TYPE_DOOR_TO_BRANCH,
        self::TYPE_DOOR_TO_DOOR
    ];
    const GROUP_FROM_BRANCH = [
        self::TYPE_BRANCH_TO_BRANCH,
        self::TYPE_BRANCH_TO_DOOR
    ];
    const LABEL_TYPES = [
        self::TYPE_DOOR_TO_DOOR     => 'Puerta a Puerta',
        self::TYPE_BRANCH_TO_DOOR   => 'Sucursal a Puerta',
        self::TYPE_DOOR_TO_BRANCH   => 'Puerta a Sucursal',
        self::TYPE_BRANCH_TO_BRANCH => 'Sucursal a Sucursal',
    ];
 
    public function toOptionArray()
    {
        $options = [];
        foreach (self::LABEL_TYPES as $type => $label) {
            $options[] = ['value' => $type, 'label' => __($label)];
        }

        return $options;
    }
}
