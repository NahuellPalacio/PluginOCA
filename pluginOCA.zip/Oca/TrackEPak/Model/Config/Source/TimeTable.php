<?php

namespace Oca\TrackEPak\Model\Config\Source;

/**
 * Class TimeTable
 * @package Oca\TrackEPak\Model\Config\Source
 */
class TimeTable
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            [
                'value' => '1',
                'label' => __('De 08:00 a 17:00 hs')
            ],
            [
                'value' => '2',
                'label' => __('De 08:00 a 12:00 hs')
            ],
            [
                'value' => '3',
                'label' => __('De 14:00 a 17:00 hs')
            ],
        ];
    }
}
