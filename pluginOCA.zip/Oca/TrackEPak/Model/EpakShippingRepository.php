<?php

namespace Oca\TrackEPak\Model;

use Oca\TrackEPak\Api\EpakShippingRepositoryInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Oca\TrackEPak\Api\Data\EpakShippingInterface;
use Oca\TrackEPak\Logger\Logger;
use Oca\TrackEPak\Model\ResourceModel\EpakShipping as EpakShippingResourceModel;
use Oca\TrackEPak\Model\ResourceModel\EpakShipping\CollectionFactory as EpakShippingCollectionFactory;

class EpakShippingRepository implements EpakShippingRepositoryInterface
{
    protected $epakShippingResourceModel;
    protected $epakShippingCollectionFactory;
    protected $logger;

    public function __construct(
        EpakShippingResourceModel $epakShippingResourceModel,
        EpakShippingCollectionFactory $epakShippingCollectionFactory,
        Logger $logger
    ) {
        $this->logger = $logger;
        $this->epakShippingResourceModel = $epakShippingResourceModel;
        $this->epakShippingCollectionFactory = $epakShippingCollectionFactory;
    }

    public function save(EpakShippingInterface $epakShipping)
    {
        try {
            $this->epakShippingResourceModel->save($epakShipping);
        } catch (\Exception $e) {
            throw new CouldNotSaveException(__($e->getMessage()));
        }
        return $epakShipping;
    }

    public function delete($epakShippingId)
    {
        $this->epakShippingResourceModel->deleteById($epakShippingId);
    }

    public function getById($epakShippingId)
    {
        try {
            $this->logger->debug('Obteniendo por id: ' . $epakShippingId);
            return $this->epakShippingResourceModel->getById($epakShippingId);
        } catch (\Exception $e) {
            $this->logger->debug($e);
        }
    }

    public function getByOrderId($orderId)
    {
        try {
            $this->logger->debug('Obteniendo por id de orden: ' . $orderId);
            return $this->epakShippingResourceModel->getByOrderId($orderId);
        } catch (\Exception $e) {
            $this->logger->debug($e);
        }
    }

    public function getNotConfirmedFromDoorByAddressId($addressId)
    {
        return $this->epakShippingCollectionFactory->create()
            ->addFieldToFilter('shipping_origin_address_id', ['eq' => $addressId])
            ->addFieldToFilter('shipping_origin_branch_postcode', ['null' => true])
            ->addFieldToFilter('shipping_epak_id', ['null' => true]);
    }
}
