<?php

namespace Oca\TrackEPak\Model\Shipping;

use Magento\Framework\Data\Collection\AbstractDb;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Model\Context;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\Registry;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Sales\Api\Data\ShipmentTrackInterface;
use Magento\Sales\Api\Data\ShipmentTrackInterfaceFactory;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Api\ShipmentRepositoryInterface;
use Magento\Sales\Model\Convert\Order as ConvertOrder;
use Magento\Sales\Model\Order\Shipment\TrackFactory;
use Magento\Sales\Model\ResourceModel\Order\Shipment\CollectionFactory as ShipmentCollectionFactory;
use Oca\TrackEPak\Api\EpakShippingRepositoryInterface;
use Oca\TrackEPak\Api\OperatoryRepositoryInterface;
use Oca\TrackEPak\Helper\Config as ConfigHelper;
use Oca\TrackEPak\Logger\Logger;
use Oca\TrackEPak\Model\Carrier\OcaShipping;
use Oca\TrackEPak\Model\Config\Source\OperatoryType;
use Oca\TrackEPak\Model\EpakShippingFactory;
use Oca\TrackEPak\Model\Ws\Ms\Adapter;

class Oca extends AbstractModel
{
    const OCA_SHIPPING_METHOD = 'ocashipping_ocashipping';

    protected $adapter;
    protected $logger;
    protected $orderRepository;
    protected $shipmentRepository;
    protected $shipmentTrackInterfaceFactory;
    protected $quoteRepository;
    protected $epakShippingRepository;
    protected $epakShippingFactory;
    protected $convertOrder;
    protected $trackFactory;
    protected $operatoryRepository;
    protected $configHelper;
    protected $shipmentCollectionFactory;

    public function __construct(
        ConfigHelper $configHelper,
        Logger $logger,
        Adapter $adapter,
        CartRepositoryInterface $quoteRepository,
        EpakShippingRepositoryInterface $epakShippingRepository,
        EpakShippingFactory $epakShippingFactory,
        OrderRepositoryInterface $orderRepository,
        ShipmentTrackInterfaceFactory $shipmentTrackInterfaceFactory,
        ShipmentRepositoryInterface $shipmentRepository,
        OperatoryRepositoryInterface $operatoryRepository,
        TrackFactory $trackFactory,
        ShipmentCollectionFactory $shipmentCollectionFactory,
        Context $context,
        Registry $registry,
        ConvertOrder $convertOrder,
        AbstractResource $resource = null,
        AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->configHelper = $configHelper;
        $this->quoteRepository = $quoteRepository;
        $this->adapter = $adapter;
        $this->logger = $logger;
        $this->orderRepository = $orderRepository;
        $this->shipmentTrackInterfaceFactory = $shipmentTrackInterfaceFactory;
        $this->shipmentRepository = $shipmentRepository;
        $this->epakShippingRepository = $epakShippingRepository;
        $this->epakShippingFactory = $epakShippingFactory;
        $this->convertOrder = $convertOrder;
        $this->trackFactory = $trackFactory;
        $this->operatoryRepository = $operatoryRepository;
        $this->shipmentCollectionFactory = $shipmentCollectionFactory;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    private function createShipmentInOrder($order)
    {

        $shipment = $this->convertOrder->toShipment($order);

        foreach ($order->getAllItems() as $orderItem) {
            if (!$orderItem->getQtyToShip() || $orderItem->getIsVirtual()) {
                continue;
            }
            $qtyShipped = $orderItem->getQtyToShip();
            $shipmentItem = $this->convertOrder->itemToShipmentItem($orderItem)->setQty($qtyShipped);
            $shipment->addItem($shipmentItem);
        }

        $shipment->register();
        $shipment->getOrder()->setIsInProcess(true);
        $shipment->getOrder()->save();
        $shipment->save();

        return $shipment;
    }

    private function getExistingShipment($order)
    {
        $orderId = $order->getId();
        $shipments = $this->shipmentCollectionFactory->create()
            ->addFieldToFilter('order_id', $orderId)
            ->load();


            if ($shipments->count()) {
            foreach ($shipments as $shipment) {
                return $shipment; // Asumimos que solo hay un envío por orden
            }
        }
        return null;
    }

    private function cancelShipment($shipment)
    {
        foreach ($shipment->getAllItems() as $item) {
            $item->cancel();
        }
        $shipment->cancel();
        $shipment->getOrder()->setIsInProcess(false);
        $shipment->getOrder()->save();
        $shipment->save();
    }

    private function updateShipmentInformation($shipment, $shippingNumber, $shippingLabel)
    {
        $this->logger->debug('Actualizando información del tracking con Epak id: ' . $shippingNumber);
        $trackingData = [
            'carrier_code' => 'OC',
            'title' => 'OCA Epak',
            'number' => $shippingNumber,
        ];
        $track = $this->trackFactory->create()->addData($trackingData);
        $shipment->addTrack($track)->save();
        $shipment->addComment("Código de seguimiento $shippingNumber;", true, true);
        $shipment->setShippingLabel($shippingLabel);
        $shipment->save();

        return $shipment;
    }

    public function updateEpakShippingInformation($epakShipping, $shipmentId, $resultCreateShipment)
    {
        $epakShipping->setShipmentId($shipmentId);
        $epakShipping->setShippingEpakId($resultCreateShipment['shippingNumber']);
        $epakShipping->setShippingEpakWithdrawalId($resultCreateShipment['shippingWithdrawalId']);
        $this->epakShippingRepository->save($epakShipping);
    }

    private function getShippingType($quote)
    {
        return (int) $quote->getData('oca_shipping_type');
    }

    public function confirmShipments($epakShippingIds)
    {

        $nroCuenta = $this->configHelper->getAccountNumber();
        $resultCreateShipments = [];

        foreach ($epakShippingIds as $epakShippingId) {
            $this->logger->debug('Preparando pre envío con id ' . $epakShippingId);
            $epakShipping = $this->epakShippingFactory->create()->load($epakShippingId);
            if (!$epakShipping->getShippingEpakId()) {
                $order = $this->orderRepository->get($epakShipping->getOrderId());
                $quote = $this->quoteRepository->get($order->getQuoteId());
                $operatory = $this->operatoryRepository->getByCode($epakShipping->getOperatoryId());

                $shippingAddress = $order->getShippingAddress();

                if (!$shippingAddress) {
                    throw new LocalizedException(__("La orden " . $order->getIncrementId() . " no tiene dirección de destino."));
                }

                if (!$shippingAddress->getPostcode()) {
                    throw new LocalizedException(__("La orden " . $order->getIncrementId() . " no tiene codigo postal de destino."));
                }

                if (!$order->canShip()) {
                    $existingShipment = $this->getExistingShipment($order);
                    if ($existingShipment) {
                        $this->cancelShipment($existingShipment);
                    } else {
                        foreach ($order->getAllItems() as $item) {
                            if ($item->getQtyToShip() == 0 && !$item->getIsVirtual()) {
                                $productName = $item->getName();
                                $qtyOrdered = $item->getQtyOrdered();
                                $qtyShipped = $qtyOrdered - $item->getQtyToShip();

                                throw new \Exception(__(
                                    "La Orden no puede ser enviada. El producto '%1' necesita ser enviado en cantidad de %2, pero actualmente tiene %3 disponible para envío.",
                                    $productName,
                                    (float)$qtyOrdered,
                                    $item->getQtyToShip()
                                ));
                            }
                        }
                        continue;
                    }
                }

                $this->logger->debug('Chequeando origen y destino...');
                if (in_array($operatory['type'], OperatoryType::GROUP_FROM_BRANCH)) {
                    $shippingAddressSource = $this->prepareForFromBranch($epakShipping);
                } else {
                    $shippingAddressSource = $this->prepareForFromDoor($epakShipping);
                }

                if ($this->getShippingType($quote) == 1) {
                    $shippingAddressDes = $this->prepareDataForToDoor($quote);
                } else {
                    $shippingAddressDes = $this->prepareDataForToBranch($quote);
                }

                $quotePackages = $this->getQuotePackages($quote);

                $this->logger->debug('Agregando pre envío a petición para Epak...');

                $shipmentToConfirm = [
                    'operativeCode' => $operatory['code'],
                    'sourceAddress' => $shippingAddressSource,
                    'destinationAddress' => $shippingAddressDes,
                    'packages' => $quotePackages,
                    'order' => $order,
                    'packagesNumber' => $epakShipping['packages_number'],
                ];

                $resultCreateShipment = $this->adapter->createShipment($shipmentToConfirm, $nroCuenta);

                if (is_array($resultCreateShipment) && isset($resultCreateShipment["status"]) && $resultCreateShipment["status"] === false) {
                    throw new LocalizedException(__("La orden " . $order->getIncrementId() . " fallo, error: " . $resultCreateShipment["message"]));
                }

                $this->logger->debug('Response: ' . json_encode($resultCreateShipment));

                if ($resultCreateShipment['status']) {
                    $shipment = $this->createShipmentInOrder($order);
                    $rawLabel = $this->adapter->generateLabel($resultCreateShipment['shippingNumber'], $resultCreateShipment['shippingWithdrawalId']);
                    $shippingLabel = base64_decode($rawLabel);
                    $this->updateShipmentInformation($shipment, $resultCreateShipment['shippingNumber'], $shippingLabel);
                    $this->updateEpakShippingInformation($epakShipping, $shipment->getId(), $resultCreateShipment);
                    $resultCreateShipments[] = $resultCreateShipment;
                }
            }
        }

        return $resultCreateShipments;
    }

    private function formatProvince($province)
    {
        return strlen($province) >= 30 ? substr($province, 0, 30) : $province;
    }

    private function prepareForFromDoor($epakShipping)
    {
        $contactInfo = $this->configHelper->getContactInfo();
        return [
            'calle' => $epakShipping['warehouse_street_and_number'], // Numero y Calle
            'nro' => '-', // Enviar solo el "-"
            'piso' => '',
            'depto' => '',
            'cp' => $epakShipping['warehouse_postal_code'],
            'localidad' => $this->sanitizeString($this->formatProvince($epakShipping['warehouse_city'])),
            'provincia' => $this->sanitizeString($this->formatProvince($epakShipping['warehouse_region'])),
            'contacto' => $contactInfo['contact_name'],
            'email' => $contactInfo['contact_email'],
            'solicitante' => $contactInfo['contact_name'],
            'centrocosto' => $epakShipping['cost_center_id'] != 0 ? $epakShipping['cost_center_id'] : "",
            'idfranjahoraria' => $this->configHelper->getTimeForReception(),
            'idcentroimposicionorigen' => "0",
            'fecha' => date('Ymd'),
            'observaciones' => "",
        ];
    }

    private function prepareForFromBranch($epakShipping)
    {
        $branches = $this->adapter->execGetCentrosImposicionConServiciosByCP($epakShipping['shipping_origin_branch_postcode']);
        $branchData = $this->findByIdCentroImposicion($branches, $epakShipping['shipping_origin_address_id']);
        $contactInfo = $this->configHelper->getContactInfo();
        return [
            'calle' => $branchData['Calle'],
            'nro' => $branchData['Numero'],
            'piso' => '',
            'depto' => '',
            'cp' => $branchData['CodigoPostal'],
            'localidad' => $branchData['Localidad'],
            'provincia' => $branchData['Provincia'],
            'contacto' => $contactInfo['contact_name'],
            'email' => $contactInfo['contact_email'],
            'solicitante' => $contactInfo['contact_name'],
            'centrocosto' => $epakShipping['cost_center_id'] != 0 ? $epakShipping['cost_center_id'] : "",
            'idfranjahoraria' => $this->configHelper->getTimeForReception(),
            'idcentroimposicionorigen' => $branchData['IdCentroImposicion'],
            'fecha' => date('Ymd'),
            'observaciones' => "",
        ];
    }

    private function findByIdCentroImposicion($branches, $idCentroImposicion)
    {
        if($branches){
            foreach ($branches as $branch) {
                if ($branch['IdCentroImposicion'] == $idCentroImposicion) {
                    return $branch;
                }
            }
        }
        throw new \Exception('No se encontró el centro de imposición ' . $idCentroImposicion . ', por favor cambie el origen del envío');
    }

    private function getQuoteOcaShippingData($quote)
    {
        return json_decode($quote->getData('oca_shipping_data'), true);
    }

    private function getQuotePackages($quote)
    {
        return $this->getQuoteOcaShippingData($quote)['package'];
    }

    private function sanitizeString($word)
    {
        $conv = array("á" => "a", "é" => "e", "í" => "i", "ó" => "o", "ú" => "u",
            "Á" => "A", "É" => "E", "Í" => "I", "Ó" => "O", "Ú" => "U");
        return strtr($word, $conv);
    }

    private function prepareDataForToBranch($quote)
    {

        $ocaShippingData = json_decode($quote->getData('oca_shipping_data'), true);
        $shippingAddress = $ocaShippingData['shipping_address'];
        return [
            'apellido' => $shippingAddress['Sigla'],
            'nombre' => $shippingAddress['Sucursal'],
            'calle' => $shippingAddress['Calle'],
            'nro' => $shippingAddress['Numero'],
            'piso' => '',
            'depto' => '',
            'localidad' => $shippingAddress['Localidad'],
            'provincia' => $shippingAddress['Provincia'],
            'cp' => $shippingAddress['CodigoPostal'],
            'telefono' => $shippingAddress['Telefono'],
            'email' => '',
            'idci' => $shippingAddress['IdCentroImposicion'],
            'observaciones' => '',
            'celular' => '',
        ];
    }

    private function prepareDataForToDoor($quote)
    {
        $shippingAddress = $quote->getShippingAddress();
        $street = $shippingAddress->getStreet();
        if (is_array($street)) {
            $street = implode(",", $street);
        }
        return [
            'apellido' => $shippingAddress->getFirstname(),
            'nombre' => $shippingAddress->getLastname(),
            'calle' => $street,
            'nro' => '-',
            'piso' => '',
            'depto' => '',
            'localidad' => $this->sanitizeString($shippingAddress->getCity()),
            'provincia' => $this->sanitizeString($shippingAddress->getRegion()),
            'cp' => $shippingAddress->getPostcode(),
            'telefono' => $shippingAddress->getTelephone(),
            'email' => $shippingAddress->getEmail(),
            'idci' => 0,
            'observaciones' => '',
            'celular' => '',
        ];
    }

    public function isOcaShipment($shipmentId)
    {
        $shipment = $this->getShipment($shipmentId);
        $order = $this->orderRepository->get($shipment->getOrderId());
        if ($order->getShippingMethod() == self::OCA_SHIPPING_METHOD) {
            return true;
        }
        return false;
    }

    public function isCreatedOcaShipment($shipmentId)
    {
        $shipment = $this->getShipment($shipmentId);
        if ($shipment->getData('oca_elocker_orden_retiro') && $shipment->getData('oca_elocker_numero_envio')) {
            return true;
        }
        return false;
    }

    private function getShipment($shipmentId)
    {
        return $this->shipmentRepository->get($shipmentId);
    }

    public function syncTrackingNumbers($shipmentId)
    {
        $listTrackingNumberSync = $this->adapter->trackingPieza($shipmentId);
        $this->addTrackingNumbers($shipmentId, $listTrackingNumberSync);
    }

    protected function addTrackingNumbers($shipmentId, $trackingDatas)
    {
        $shipment = $this->shipmentRepository->get($shipmentId);
        $currentTracks = $shipment->getTracks();
        foreach ($trackingDatas as $trackingData) {
            if ($this->isTrackingDataExists($currentTracks, $trackingData['track_number'])) {
                continue;
            }
            $track = $this->shipmentTrackInterfaceFactory->create()->setNumber(
                $trackingData['track_number']
            )->setCarrierCode(
                OcaShipping::CARRIER_CODE
            )->setTitle(
                $trackingData['description']
            );
            $shipment->addTrack($track);
        }
        $this->shipmentRepository->save($shipment);
    }

    /**
     * @param ShipmentTrackInterface[] $currentTrackingDatas
     * @param $trackingNumber
     * @return bool
     */
    private function isTrackingDataExists($currentTrackingDatas, $trackingNumber)
    {
        foreach ($currentTrackingDatas as $trackingData) {
            if ($trackingData->getTrackNumber() == $trackingNumber) {
                return true;
            }
        }
        return false;
    }

    public function cancelOcaShipment($epakShipping)
    {
        $order = $this->orderRepository->get($epakShipping->getOrderId());

        $status = $order->getStatus();
        $order->setState('canceled');
        $order->setStatus('canceled');
        $order->save();
        $statusChanged = $order->getStatus();

        $this->logger->debug('Changed status of the order ' . $epakShipping->getOrderId() . ' ' . $status . '->' . $statusChanged);

        $ordenRetiro = $epakShipping->getShippingEpakWithdrawalId();
        return $this->adapter->anularOrdenGenerada($ordenRetiro);
    }

    /**
     * @param integer $shipmentId
     * @return array
     */
    public function getOcaShipmentInfo($shipmentId)
    {
        $shipment = $this->getShipment($shipmentId);
        return [
            'orden_retiro' => $shipment->getData('oca_elocker_orden_retiro'),
            'numero_envio' => $shipment->getData('oca_elocker_numero_envio'),
        ];
    }
}
