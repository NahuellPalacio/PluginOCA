<?php

namespace Oca\TrackEPak\Logger;

use Magento\Framework\Logger\Handler\Base;

class Handler extends Base
{
    protected $loggerType = Logger::DEBUG;
    protected $fileName = '/var/log/oca-epak-debug.log';
}