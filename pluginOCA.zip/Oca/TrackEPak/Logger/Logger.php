<?php

namespace Oca\TrackEPak\Logger;

use Monolog\Logger as MonologLogger;

class Logger extends MonologLogger
{
}