<?php

namespace Oca\TrackEPak\Block\Adminhtml\Product;

use Magento\Backend\Block\Widget\Grid\Extended;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Backend\Block\Template\Context;
use Magento\Backend\Helper\Data as BackendHelper;

class InvalidDimensionsGrid extends Extended
{
    protected $productCollectionFactory;

    public function __construct(
        Context $context,
        BackendHelper $backendHelper,
        CollectionFactory $productCollectionFactory,
        array $data = []
    ) {
        $this->productCollectionFactory = $productCollectionFactory;
        parent::__construct($context, $backendHelper, $data);
    }

    protected function _prepareCollection()
    {
        $collection = $this->productCollectionFactory->create()
            ->addAttributeToSelect(['name', 'sku', 'oca_alto', 'oca_ancho', 'oca_largo'])
            ->addAttributeToFilter([
                ['attribute' => 'oca_alto', 'null' => true],
                ['attribute' => 'oca_ancho', 'null' => true],
                ['attribute' => 'oca_largo', 'null' => true]
            ]);

        $this->setCollection($collection);

        return parent::_prepareCollection();
    }

    protected function _prepareColumns()
    {
        $this->addColumn(
            'entity_id',
            [
                'header' => __('ID'),
                'sortable' => true,
                'index' => 'entity_id'
            ]
        );
        $this->addColumn(
            'name',
            [
                'header' => __('Name'),
                'index' => 'name'
            ]
        );
        $this->addColumn(
            'sku',
            [
                'header' => __('SKU'),
                'index' => 'sku'
            ]
        );
        $this->addColumn(
            'oca_alto',
            [
                'header' => __('Alto'),
                'index' => 'oca_alto'
            ]
        );
        $this->addColumn(
            'oca_ancho',
            [
                'header' => __('Ancho'),
                'index' => 'oca_ancho'
            ]
        );
        $this->addColumn(
            'oca_largo',
            [
                'header' => __('Largo'),
                'index' => 'oca_largo'
            ]
        );

        $this->addColumn(
            'action',
            [
                'header' => __('Edit'),
                'type' => 'action',
                'getter' => 'getId',
                'actions' => [
                    [
                        'caption' => __('Edit'),
                        'url' => ['base' => 'catalog/product/edit'],
                        'field' => 'id'
                    ]
                ],
                'filter' => false,
                'sortable' => false,
                'index' => 'stores',
                'header_css_class' => 'col-action',
                'column_css_class' => 'col-action'
            ]
        );

        return parent::_prepareColumns();
    }
}
