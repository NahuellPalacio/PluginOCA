<?php

namespace Oca\TrackEPak\Block\Adminhtml\Product;

use Magento\Backend\Block\Template;
use Oca\TrackEPak\ViewModel\Product\InvalidDimensions as InvalidDimensionsViewModel;

class InvalidDimensions extends Template
{
    protected $invalidDimensionsViewModel;

    public function __construct(
        Template\Context $context,
        InvalidDimensionsViewModel $invalidDimensionsViewModel,
        array $data = []
    ) {
        $this->invalidDimensionsViewModel = $invalidDimensionsViewModel;
        parent::__construct($context, $data);
    }

    public function getInvalidDimensionsProducts()
    {
        return $this->invalidDimensionsViewModel->getProducts();
    }
}
