<?php

namespace Oca\TrackEPak\ViewModel\Product;

use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Framework\View\Element\Block\ArgumentInterface;

class InvalidDimensions implements ArgumentInterface
{
    protected $productCollectionFactory;

    public function __construct(CollectionFactory $productCollectionFactory)
    {
        $this->productCollectionFactory = $productCollectionFactory;
    }

    public function getProducts()
    {
        $collection = $this->productCollectionFactory->create()
            ->addAttributeToSelect(['name', 'sku', 'oca_alto', 'oca_ancho', 'oca_largo'])
            ->addAttributeToFilter(
                [
                    ['attribute' => 'oca_alto', 'null' => true],
                    ['attribute' => 'oca_ancho', 'null' => true],
                    ['attribute' => 'oca_largo', 'null' => true]
                ],
                null,
                'left'
            );

        return $collection;
    }
}
