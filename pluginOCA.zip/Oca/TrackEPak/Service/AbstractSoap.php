<?php

namespace Oca\TrackEPak\Service;

use Oca\TrackEPak\Helper\Config as ConfigHelper;
use Oca\TrackEPak\Model\RequestHistory;
use Oca\TrackEPak\Model\RequestHistoryRepository;
use Laminas\Soap\Client;
use Laminas\Soap\ClientFactory;


/**
 * Class Soap
 * @package Oca\TrackEPak\Service
 */
abstract class AbstractSoap
{
    const OCA_USER_FIELD = 'usr';

    const OCA_PASSWORD_FIELD = 'psw';

    /**
     * @var ConfigHelper
     */
    protected $configHelper;

    /**
     * @var ClientFactory
     */
    protected $soapClientFactory;

    protected $baseWsdlLink;

    /**
     * @var RequestHistory
     */
    protected $requestHistory;

    /**
     * @var RequestHistoryRepository
     */
    protected $requestHistoryRepository;

    /**
     * AbstractSoap constructor.
     * @param RequestHistory $requestHistory
     * @param RequestHistoryRepository $requestHistoryRepository
     * @param ConfigHelper $config
     * @param ClientFactory $clientFactory
     */
    public function __construct(
        RequestHistory $requestHistory,
        RequestHistoryRepository $requestHistoryRepository,
        ConfigHelper $config,
        ClientFactory $clientFactory
    ) {
        $this->configHelper = $config;
        $this->soapClientFactory = $clientFactory;
        $this->requestHistory = $requestHistory;
        $this->requestHistoryRepository = $requestHistoryRepository;
    }

    /**
     * @return Client
     */
    public function createNewSoapClient()
    {
        $this->baseWsdlLink = $this->configHelper->getOcaSoapUrl();
        return $this->soapClientFactory
                    ->create(['wsdl' => $this->configHelper->getOcaSoapUrl()]);
    }

    /**
     * @return Client
     */
    public function createNewSoapELockerClient()
    {
        $this->baseWsdlLink = $this->configHelper->getOcaElockerSoapUrl();
        return $this->soapClientFactory->create(['wsdl' => $this->baseWsdlLink]);
    }

    /**
     * @param array $inputData
     * @return mixed
     */
    abstract protected function handleApi($inputData = null);

    /**
     * @param $request
     * @return mixed
     */
    abstract protected function prepareParams($request);

    /**
     * @return mixed
     */
    abstract protected function sendRequest();

    /**
     * @param $response
     * @return mixed
     */
    abstract protected function parseResponse($response);

    /**
     * @param $request
     * @param $response
     * @return mixed
     */
    abstract protected function writeLogRequest($request, $response);
}
