<?php

namespace Oca\TrackEPak\Service;

use Laminas\Soap\ClientFactory;
use Magento\Quote\Model\Quote\Address\RateRequest;
use Oca\TrackEPak\Helper\Config as ConfigHelper;
use Oca\TrackEPak\Model\RequestHistory;
use Oca\TrackEPak\Model\RequestHistoryRepository;
use Psr\Log\LoggerInterface;

/**
 * Class Soap
 * @package Oca\TrackEPak\Service
 */
class GetShippingPrice extends AbstractSoap
{
    protected $params = [];
    const LBS_TO_KGS_RATE = 0.45;
    const INCH_TO_METRE_RATE = 0.0254;
    const DEFAULT_WEIGHT = 10; //kgs
    const VOLUME_DIVISION = 4000;
    const DEFAULT_VOLUME = 0.001;
    const NUMBER_OF_PACKAGE = 1;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var ConfigHelper
     */
    protected $configHelper;

    /**
     * @var ClientFactory
     */
    protected $soapClientFactory;

    /**
     * @var RequestHistoryRepository
     */
    protected $requestHistoryRepository;

    /**
     * @var RequestHistory
     */
    protected $requestHistory;

    /**
     * ShippingInformationManagement constructor.
     * @param LoggerInterface $logger
     * @param RequestHistory $requestHistory
     * @param RequestHistoryRepository $requestHistoryRepository
     * @param ConfigHelper $config
     * @param ClientFactory $clientFactory
     */
    public function __construct(
        LoggerInterface $logger,
        RequestHistory $requestHistory,
        RequestHistoryRepository $requestHistoryRepository,
        ConfigHelper $config,
        ClientFactory $clientFactory

    ) {
        $this->logger = $logger;
        parent::__construct($requestHistory, $requestHistoryRepository, $config, $clientFactory);

    }

    /**
     * @inheritdoc
     */
    public function handleApi($inputData = null, $consolidatedDimensions = null,$operative = null)
    {
        if ($inputData instanceof \Magento\Framework\DataObject) {
            $inputData->addData([
                "consolidated_dimensions" => $consolidatedDimensions,
                "operative" => $operative,
            ]);
        }

        $this->prepareParams($inputData);
        return ($this->sendRequest());
    }

    /**
     * @param RateRequest|null $request
     * @return array|mixed
     */
    protected function prepareParams($request)
    {
        $consolidatedDimensions = $request->getConsolidatedDimensions();

        if (!$consolidatedDimensions) {
            $this->logger->error('No se pueden calcular las dimensiones consolidadas.');
            return false;
        }

        $weightUnit = $this->configHelper->getWeightUnit();
        $cuit = $this->configHelper->getCuit();

        $weightRate = self::LBS_TO_KGS_RATE;
        if ($weightUnit == 'kgs') {
            $weightRate = 1;
        }

        $orderTotalWeight = 0;
        $subtotal = 0;

        foreach ($request->getAllItems() as $item) {
            if (!$item->getIsVirtual()) {
                $orderTotalWeight += $item->getRowWeight() * $weightRate;
                $subtotal += $item->getRowTotal();
            }
        }

        $operative=$request->getOperative();

        $volume = $consolidatedDimensions['volume'];

        $orderTotalWeight = ($orderTotalWeight > self::DEFAULT_WEIGHT) ? $orderTotalWeight : self::DEFAULT_WEIGHT;
        $totalVolume = ($volume > self::DEFAULT_VOLUME) ? $volume : self::DEFAULT_VOLUME;

        $this->params = [
            'PesoTotal' => $orderTotalWeight,
            'VolumenTotal' => $totalVolume,
            'CodigoPostalOrigen' => $this->configHelper->getWarehouseZipCode(),
            'CodigoPostalDestino' => $request->getDestPostcode(),
            'CantidadPaquetes' => self::NUMBER_OF_PACKAGE,
            'ValorDeclarado' => $subtotal,
            'Cuit' => $cuit,
            'Operativa' => $operative["code"],
        ];

        $this->logger->info('params', $this->params);
    }

    /**
     * @inheritdoc
     */
    protected function sendRequest()
    {
        $client = $this->createNewSoapELockerClient();
        try {
            $total = 0;
            $requestLink = $client->getWSDL() . '&&op=Tarifar_Envio_Corporativo';
            $this->requestHistory
                ->setRequestLink($requestLink)
                ->setStatus('success');
            $result = $client->call('Tarifar_Envio_Corporativo', [$this->params]);
            $result = simplexml_load_string($result->Tarifar_Envio_CorporativoResult->any);


            foreach ($result->children() as $secondGen) {
                foreach ($secondGen->children() as $thirdGen) {
                    $total = $thirdGen->Total;
                }
            }
        } catch (\SoapFault $exception) {
            $this->requestHistory->setStatus('fail');
            return false;
        }

        $this->requestHistory
            ->setRequestData($client->getLastRequest())
            ->setResponseData($client->getLastResponse());

        $this->requestHistoryRepository->save($this->requestHistory);

        return round($total * 1.21, 0);
    }

    /**
     *
     */
    protected function saveRequestApi()
    {
    }

    /**
     * @inheritdoc
     */
    protected function parseResponse($response)
    {
    }

    /**
     * @param $request
     * @param $response
     * @return mixed
     */
    protected function writeLogRequest($request, $response)
    {
    }
}
