<?php

namespace Oca\TrackEPak\Ui\Component\Listing\Column;

use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Ui\Component\Listing\Columns\Column;
use Oca\TrackEPak\Helper\Config;

class EpakShippingActions extends Column
{
    const URL_PATH_CONFIRM = 'oca_track_epak/oca_shipping/confirm';
    const URL_PATH_PRINT_PDF = 'oca_track_epak/oca_shipping/printlabel';
    const URL_PATH_DELETE = 'oca_track_epak/oca_shipping/delete';
    const URL_PATH_VIEW = 'sales/order/view';
    const URL_PATH_CANCEL = 'oca_track_epak/oca_shipping/cancel';

    protected $urlBuilder;
    protected $configHelper;

    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
        Config $configHelper,
        array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
        $this->configHelper = $configHelper;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                if (isset($item['entity_id'])) {
                    if (!isset($item['shipping_epak_id'])) {
                        $item[$this->getData('name')] = [
                            'confirm' => $this->getAction('confirm', $item),
                            'change' => $this->getAction('change', $item),
                            'packages' => $this->getAction('packages', $item),
                            'delete' => $this->getAction('delete', $item),
                        ];
                    } else if (!(strpos($item['shipping_epak_id'], 'cancel') !== false)) {
                        $item[$this->getData('name')] = [
                            'print' => $this->getAction('print', $item),
                            'cancel' => $this->getAction('cancel', $item),
                            'track' => $this->getAction('track', $item),
                        ];
                    }
                    $item[$this->getData('name')]['view'] = $this->getAction('view', $item);
                }
            }
        }
        return $dataSource;
    }

    private function getAction($action, $item)
    {
        $actions = [
            'confirm' => [
                'href' => $this->urlBuilder->getUrl(
                    static::URL_PATH_CONFIRM,
                    [
                        'entity_id' => $item['entity_id'],
                    ]
                ),
                'label' => __('Confirmar'),
                'confirm' => [
                    'title' => __('Confirmar envío de la orden "' . $item['increment_id'] . '"'),
                    'message' => __('¿Estás seguro de confirmar el envío de la orden "' . $item['increment_id'] . '"?'),
                ],
            ],
            'print' => [
                'href' => $this->urlBuilder->getUrl(
                    static::URL_PATH_PRINT_PDF,
                    [
                        'shipment_id' => $item['shipment_id'],
                        'shipping_epak_id' => $item['shipping_epak_id'],
                    ]
                ),
                'label' => __('Imprimir etiqueta'),
            ],
            'delete' => [
                'href' => $this->urlBuilder->getUrl(
                    static::URL_PATH_DELETE,
                    [
                        'entity_id' => $item['entity_id'],
                    ]
                ),
                'label' => __('Eliminar'),
                'confirm' => [
                    'title' => __('Eliminar "' . $item['increment_id'] . '"'),
                    'message' => __('¿Estás seguro de eliminar el envío de la orden "' . $item['increment_id'] . '"?'),
                ],
            ],
            'cancel' => [
                'href' => $this->urlBuilder->getUrl(
                    static::URL_PATH_CANCEL,
                    [
                        'entity_id' => $item['entity_id'],
                    ]
                ),
                'label' => __('Cancelar'),
                'confirm' => [
                    'title' => __('Cancelar "' . $item['increment_id'] . '"'),
                    'message' => __('¿Estás seguro de cancelar el envío de la orden "' . $item['increment_id'] . '"?'),
                ],
            ],
            'view' => [
                'href' => $this->urlBuilder->getUrl(
                    static::URL_PATH_VIEW,
                    [
                        'order_id' => $item['order_id'],
                    ]
                ),
                'label' => __('Ver orden'),
            ],
            'track' => [
                'href' => $this->configHelper->getTrackingUrl() . $item['shipping_epak_id'],
                'target' => '_blank',
                'label' => __('Seguimiento'),
            ],
            'change' => [
                'callback' => [
                    [
                        'provider' => 'oca_track_epak_shipping_listing.oca_track_epak_shipping_listing.change_origin_modal',
                        'target' => 'changeShippingOrigin',
                        'params' => [
                            'order_id' => $item['order_id'],
                            'entity_id' => $item['entity_id'],
                            'operatory_id' => $item['operatory_id'],
                            'increment_id' => $item['increment_id'],
                            'operatory_description' => $item['operatory_description'],
                            'origin_address' => $item['origin_address'],
                        ],
                    ],
                ],
                'href' => '#',
                'label' => __('Cambiar origen de envío'),
            ],
            'packages' => [
                'callback' => [
                    [
                        'provider' => 'oca_track_epak_shipping_listing.oca_track_epak_shipping_listing.change_packages_number_modal',
                        'target' => 'changePackages',
                        'params' => [
                            'order_id' => $item['order_id'],
                            'entity_id' => $item['entity_id'],
                            'increment_id' => $item['increment_id'],
                            'packages_number' => $item['packages_number'],
                        ],
                    ],
                ],
                'href' => '#',
                'label' => __('Configurar cantidad de bultos'),
            ]
        ];
        return $actions[$action];
    }

}
