<?php

namespace Oca\TrackEPak\Observer;

use Oca\TrackEPak\Model\Carrier\OcaShipping;

class SalesOrder
{

  public function __construct()
  {
  }

  protected function isEpakShipping($shippingMethod)
  {
    if ($shippingMethod == OcaShipping::CARRIER_CODE . '_' . OcaShipping::CARRIER_CODE) {
      return true;
    }

    $services=explode("_",$shippingMethod);

    if($services[0] === OcaShipping::CARRIER_CODE ) {
        return true;
    }

    return false;
  }
}
