<?php
// Archivo: Observer/ValidateAllProductDimensions.php

namespace Oca\TrackEPak\Observer;

use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Framework\Escaper;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\LayoutInterface;

class ValidateAllProductDimensions implements ObserverInterface
{
    protected $productCollectionFactory;
    protected $messageManager;
    protected $urlBuilder;
    protected $escaper;
    protected $layout;

    public function __construct(
        CollectionFactory $productCollectionFactory,
        ManagerInterface $messageManager,
        UrlInterface $urlBuilder,
        Escaper $escaper,
        LayoutInterface $layout
    ) {
        $this->productCollectionFactory = $productCollectionFactory;
        $this->messageManager = $messageManager;
        $this->urlBuilder = $urlBuilder;
        $this->escaper = $escaper;
        $this->layout = $layout;
    }

    public function execute(Observer $observer)
    {
        $products = $this->productCollectionFactory->create()
            ->addAttributeToSelect(['oca_alto', 'oca_ancho', 'oca_largo']);

        $invalidProductsCount = 0;

        foreach ($products as $product) {
            if (!$product->getData('oca_alto') || !$product->getData('oca_ancho') || !$product->getData('oca_largo')) {
                $invalidProductsCount++;
            }
        }

        if ($invalidProductsCount > 0) {
            $url = $this->urlBuilder->getUrl('oca_track_epak/product/invaliddimensions');
            $link = $this->escaper->escapeHtml($url);
            $message = sprintf(
                "Existen productos cargados sin dimensiones: %d. <a href='%s' style='color: red; font-weight: bold;'>Ver catálogo</a>",
                $invalidProductsCount,
                $link
            );

            $this->messageManager->addComplexNoticeMessage(
                'ocaError',
                [
                    'message' => $message,
                ]
            );
        }
    }
}
