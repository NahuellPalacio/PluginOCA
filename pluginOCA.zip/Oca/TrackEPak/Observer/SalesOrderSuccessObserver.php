<?php

namespace Oca\TrackEPak\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Oca\TrackEPak\Api\EpakShippingRepositoryInterface;
use Oca\TrackEPak\Api\OperatoryRepositoryInterface;
use Oca\TrackEPak\Helper\Config;
use Oca\TrackEPak\Logger\Logger;
use Oca\TrackEPak\Model\Config\Source\OperatoryType;
use Oca\TrackEPak\Model\EpakShippingFactory;

class SalesOrderSuccessObserver extends SalesOrder implements ObserverInterface
{
    const PACKAGES_NUMBER_DEFAULT = 1;

    protected $epakShippingRepository;
    protected $operatoryRepository;
    protected $epakShippingFactory;
    protected $quoteRepository;
    protected $logger;
    protected $configHelper;

    public function __construct(
        EpakShippingRepositoryInterface $epakShippingRepository,
        OperatoryRepositoryInterface $operatoryRepository,
        EpakShippingFactory $epakShippingFactory,
        CartRepositoryInterface $quoteRepository,
        Logger $logger,
        Config $configHelper
    ) {
        $this->epakShippingRepository = $epakShippingRepository;
        $this->operatoryRepository = $operatoryRepository;
        $this->epakShippingFactory = $epakShippingFactory;
        $this->quoteRepository = $quoteRepository;
        $this->logger = $logger;
        $this->configHelper = $configHelper;
    }

    public function execute(Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();
        $orderId = $order->getId();
        $this->logger->debug('Chequeando shipping de la orden: ' . $orderId . ' ' . $order->getIncrementId());
        try {
            if ($this->isEpakShipping($order->getShippingMethod())) {
                $services = explode("_", $order->getShippingMethod());
                $selectedOperatoryId = $services[2];
                $epakShippingToSave = $this->createEpakShipping($order, $selectedOperatoryId);
                $this->epakShippingRepository->save($epakShippingToSave);
                $this->logger->debug('OK: El pre envio de la orden ' . $orderId . ' fue guardado correctamente');
            }
        } catch (\Exception $error) {
            $this->logger->debug('ERROR al procesar la orden ' . $orderId . ' para OCA');
            $this->logger->error($error->getMessage());
        }
    }

    private function createEpakShipping($order, $selectedOperatoryId)
    {
        try {
            $operatory = $this->operatoryRepository->getByCode($selectedOperatoryId);
            $this->logger->debug('Operativa: ' . json_encode($operatory));
            $epakShippingToSave = $this->epakShippingFactory->create();
            $epakShippingToSave->setOrderId($order->getId());
            $epakShippingToSave->setIncrementId($order->getIncrementId());
            $epakShippingToSave->setPackagesNumber(self::PACKAGES_NUMBER_DEFAULT);
            $epakShippingToSave->setOperatoryDescription(isset($operatory['name']) ? $selectedOperatoryId . ' - ' . $operatory['name'] : $selectedOperatoryId);
            $epakShippingToSave->setOperatoryId($selectedOperatoryId);
            $epakShippingToSave->setCostCenterId($operatory['cost_center_id']);
            $epakShippingToSave->setCostCenterDescription($operatory['cost_center_description']);

            if (in_array($operatory['type'], OperatoryType::GROUP_FROM_BRANCH)) {
                $this->logger->debug('Direccion sucursal: ' . $operatory['default_branch_description']);
                $epakShippingToSave->setShippingOriginBranchPostcode($operatory['default_branch_postal_code']);
                $epakShippingToSave->setShippingOriginAddressId($operatory['default_branch_id']);
                $originDesc = 'Sucursal: ' . $operatory['default_branch_description'];
            } else {
                $street = $this->configHelper->getWarehouseStreet();
                $city = $this->configHelper->getWarehouseCity();
                $postalCode = $this->configHelper->getWarehouseZipCode();
                $region = (!empty($this->configHelper->getWarehouseRegion())) ? $this->configHelper->getWarehouseRegion() : '';

                $epakShippingToSave->setShippingOriginAddressId(0);
                $epakShippingToSave->setWarehouseStreetAndNumber($street);
                $epakShippingToSave->setWarehouseRegion($region);
                $epakShippingToSave->setWarehouseCity($city);
                $epakShippingToSave->setWarehousePostalCode($postalCode);
                $originDesc = 'Puerta: ' . $street . ', ' . $city . ', ' . $region;
            }

            $this->logger->debug("Default shipping" . $originDesc);
            $epakShippingToSave->setOriginAddress($originDesc);
            return $epakShippingToSave;
        } catch (\Exception $e) {
            $this->logger->debug($e->getMessage());
        }
    }

}
