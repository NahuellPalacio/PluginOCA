<?php

namespace Oca\TrackEPak\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Message\ManagerInterface;

class ValidateProductDimensionsOnSave implements ObserverInterface
{
    protected $messageManager;

    public function __construct(ManagerInterface $messageManager)
    {
        $this->messageManager = $messageManager;
    }

    public function execute(Observer $observer)
    {
        $product = $observer->getEvent()->getProduct();

        if (!$product->getData('oca_alto') || !$product->getData('oca_ancho') || !$product->getData('oca_largo')) {
            $this->messageManager->addErrorMessage(__("El producto %1 no tiene dimensiones cargadas para OCA.", $product->getName()));
        }
    }
}
