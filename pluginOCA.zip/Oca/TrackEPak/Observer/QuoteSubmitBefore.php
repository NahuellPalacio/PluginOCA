<?php

namespace Oca\TrackEPak\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;

/**
 * Quote Submit Before
 */
class QuoteSubmitBefore implements ObserverInterface
{


    /**
     * @var LoggerInterface
     */
    protected $logger;


    /**
     * ShippingInformationManagement constructor.
     * @param LoggerInterface $logger
     */
    public function __construct(
        LoggerInterface $logger

    ) {
        $this->logger = $logger;

    }

    /**
     * Save data from quote to order
     *
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $this->logger->info('===== QuoteSubmitBefore');

        $order = $observer->getEvent()->getData('order');
        $quote = $observer->getEvent()->getData('quote');

        $order->setData('oca_shipping_type', $quote->getData('oca_shipping_type'));
        $order->setData('oca_shipping_data', $quote->getData('oca_shipping_data'));

        $this->logger->info('ORDER oca_shipping', [
            'type' => $order->getData('oca_shipping_type'),
            'data' => $order->getData('oca_shipping_data')
        ]);
    }
}
