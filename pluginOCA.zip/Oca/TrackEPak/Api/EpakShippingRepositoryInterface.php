<?php

namespace Oca\TrackEPak\Api;

use Oca\TrackEPak\Api\Data\EpakShippingInterface;

interface EpakShippingRepositoryInterface
{
    public function save(EpakShippingInterface $epakShipping);
    public function delete($epakShippingId);
    public function getById($epakShippingId);
    public function getByOrderId($orderId);
    public function getNotConfirmedFromDoorByAddressId($addressId);
}
