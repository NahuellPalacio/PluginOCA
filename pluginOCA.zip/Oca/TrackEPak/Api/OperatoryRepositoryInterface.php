<?php

namespace Oca\TrackEPak\Api;

use Magento\Framework\Exception\LocalizedException;
use Oca\TrackEPak\Api\Data\OperatoryInterface;

/**
 * Interface OperatoryRepositoryInterface
 * @package Oca\TrackEPak\Api
 */
interface OperatoryRepositoryInterface
{

    public function save(OperatoryInterface $operatory);
    public function get($operatoryId);
    public function getByCode($code);
    public function delete($operatoryId);
    public function getActives();
}
