<?php

namespace Oca\TrackEPak\Api;

use Magento\Framework\Exception\LocalizedException;
use Oca\TrackEPak\Api\Data\RequestHistoryInterface;

/**
 * Interface RequestHistoryRepositoryInterface
 * @package Oca\TrackEPak\Api
 */
interface RequestHistoryRepositoryInterface
{
    /**
     * @param RequestHistoryInterface $requestHistory
     * @return RequestHistoryInterface
     */
    public function save(RequestHistoryInterface $requestHistory);

    /**
     * @param int $requestHistoryId
     * @return RequestHistoryInterface
     * @throws LocalizedException
     */
    public function get($requestHistoryId);

    /**
     * @param int $requestHistoryId
     * @throws LocalizedException
     */
    public function delete($requestHistoryId);
}
