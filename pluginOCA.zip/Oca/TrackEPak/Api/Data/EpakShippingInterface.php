<?php

namespace Oca\TrackEPak\Api\Data;

interface EpakShippingInterface
{
    const ENTITY_ID = 'entity_id';
    const ORDER_ID = 'order_id';
    const SHIPMENT_ID = 'shipment_id';
    const INCREMENT_ID = 'increment_id';
    const CREATED_AT = 'created_at';
    const SHIPPING_ORIGIN_BRANCH_POSTCODE = 'shipping_origin_branch_postcode';
    const SHIPPING_EPAK_ID = 'shipping_epak_id';
    const SHIPPING_ORIGIN_ADDRESS_ID = 'shipping_origin_address_id';
    const SHIPPING_EPAK_WITHDRAWAL_ID = 'shipping_epak_withdrawal_id';
    const OPERATORY_DESCRIPTION = 'operatory_description';
    const WAREHOUSE_STREET_AND_NUMBER = 'warehouse_street_and_number';
    const WAREHOUSE_CITY = 'warehouse_city';
    const WAREHOUSE_REGION = 'warehouse_region';
    const WAREHOUSE_POSTAL_CODE = 'warehouse_postal_code';
    const OPERATORY_ID = 'operatory_id';
    const ORIGIN_ADDRESS = 'origin_address';
    const PACKAGES_NUMBER = 'packages_number';
    const COST_CENTER_ID = 'cost_center_id';
    const COST_CENTER_DESCRIPTION = 'cost_center_description';

    public function getEntityId();
    public function setEntityId($entityId);

    public function getOrderId();
    public function setOrderId($orderId);

    public function getShipmentId();
    public function setShipmentId($shipmentId);

    public function getIncrementId();
    public function setIncrementId($incrementId);

    public function getCreatedAt();
    public function setCreatedAt($createdAt);

    public function getShippingEpakId();
    public function setShippingEpakId($shippingEpakId);

    public function getShippingOriginBranchPostcode();
    public function setShippingOriginBranchPostcode($shippingOriginBranchPostcode);

    public function getShippingOriginAddressId();
    public function setShippingOriginAddressId($shippingOriginAddressId);

    public function getShippingEpakWithdrawalId();
    public function setShippingEpakWithdrawalId($shippingEpakWithdrawalId);

    public function getOperatoryDescription();
    public function setOperatoryDescription($operatoryDescription);

    public function getOperatoryId();
    public function setOperatoryId($operatoryId);

    public function getOriginAddress();
    public function setOriginAddress($originAddress);

    public function getWarehouseStreetAndNumber();
    public function setWarehouseStreetAndNumber($warehouseStreetAndNumber);

    public function getWarehouseCity();
    public function setWarehouseCity($warehouseCity);

    public function getWarehouseRegion();
    public function setWarehouseRegion($warehouseRegion);

    public function getWarehousePostalCode();
    public function setWarehousePostalCode($warehousePostalCode);

    public function getPackagesNumber();
    public function setPackagesNumber($packagesNumber);

    public function getCostCenterId();
    public function setCostCenterId($costCenterId);

    public function getCostCenterDescription();
    public function setCostCenterDescription($costCenterDescription);
}
