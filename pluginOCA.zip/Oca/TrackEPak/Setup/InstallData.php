<?php

namespace Oca\TrackEPak\Setup;

use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Framework\Message\ManagerInterface;

class InstallData implements InstallDataInterface
{
    protected $productCollectionFactory;
    protected $messageManager;

    public function __construct(
        CollectionFactory $productCollectionFactory,
        ManagerInterface $messageManager
    ) {
        $this->productCollectionFactory = $productCollectionFactory;
        $this->messageManager = $messageManager;
    }

    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        $products = $this->productCollectionFactory->create()
            ->addAttributeToSelect(['oca_alto', 'oca_ancho', 'oca_largo']);

        $invalidProductsCount = 0;

        foreach ($products as $product) {
            if (!$product->getData('oca_alto') || !$product->getData('oca_ancho') || !$product->getData('oca_largo')) {
                $invalidProductsCount++;
            }
        }

        if ($invalidProductsCount > 0) {
            $this->messageManager->addErrorMessage(__("Existen productos cargados sin dimensiones: %1", $invalidProductsCount));
        }

        $setup->endSetup();
    }
}
