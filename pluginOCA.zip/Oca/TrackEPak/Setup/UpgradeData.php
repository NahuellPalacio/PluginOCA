<?php

namespace Oca\TrackEPak\Setup;

use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Catalog\Model\Product;

class UpgradeData implements UpgradeDataInterface
{
    /**
     * @var EavSetupFactory
     */
    private $eavSetupFactory;

    /**
     * UpgradeData constructor.
     * @param EavSetupFactory $eavSetupFactory
     */
    public function __construct(EavSetupFactory $eavSetupFactory)
    {
        $this->eavSetupFactory = $eavSetupFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        $attributes = [
            'oca_alto' => [
                'type' => 'decimal',
                'label' => 'OCA Alto',
                'input' => 'text',
                'required' => false,
                'sort_order' => 209,
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                'visible' => true,
                'user_defined' => true,
                'group' => 'General',
            ],
            'oca_ancho' => [
                'type' => 'decimal',
                'label' => 'OCA Ancho',
                'input' => 'text',
                'required' => false,
                'sort_order' => 210,
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                'visible' => true,
                'user_defined' => true,
                'group' => 'General',
            ],
            'oca_largo' => [
                'type' => 'decimal',
                'label' => 'OCA Largo',
                'input' => 'text',
                'required' => false,
                'sort_order' => 211,
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                'visible' => true,
                'user_defined' => true,
                'group' => 'General',
            ],
        ];

        foreach ($attributes as $attributeCode => $attributeData) {
            $eavSetup->addAttribute(Product::ENTITY, $attributeCode, $attributeData);
        }

        $attributeSetIds = $eavSetup->getAllAttributeSetIds(Product::ENTITY);

        foreach ($attributeSetIds as $attributeSetId) {
            $groupId = $eavSetup->getDefaultAttributeGroupId(Product::ENTITY, $attributeSetId);

            foreach (array_keys($attributes) as $attributeCode) {
                $eavSetup->addAttributeToSet(Product::ENTITY, $attributeSetId, $groupId, $attributeCode);
            }
        }
    }
}

?>

<!--
sudo php8.2 bin/magento setup:di:compile
sudo php8.2 bin/magento setup:upgrade
sudo php8.2 bin/magento setup:static-content:deploy -f
sudo php8.2 bin/magento cache:clean
C:\elasticsearch\bin\elasticsearch.bat

php8 bin/magento setup:di:compile
php8 bin/magento setup:upgrade
php8 bin/magento setup:static-content:deploy -f
php8 bin/magento cache:clean
php8 bin/magento cache:flush

php8 bin/magento cache:clean
php8 bin/magento cache:flush
php8 bin/magento setup:di:compile
php8 bin/magento setup:static-content:deploy -f
php8 bin/magento indexer:reindex
-->
